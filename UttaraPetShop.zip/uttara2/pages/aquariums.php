<?php
require_once '../includes/config.php'; require_once '../includes/layout.php'; requireLogin();
$msg='';$msgType='success';
if($_SERVER['REQUEST_METHOD']==='POST'){
    $action=$_POST['action']??'';
    if($action==='add'||$action==='edit'){
        $id=(int)($_POST['id']??0);$name=clean($_POST['name']);$size=(float)$_POST['size_liters'];$price=(float)$_POST['price'];$qty=(int)$_POST['stock_quantity'];$mat=clean($_POST['material']);$desc=clean($_POST['description']);
        if($action==='add'){$conn->query("INSERT INTO aquariums (name,size_liters,price,stock_quantity,material,description) VALUES ('$name',$size,$price,$qty,'$mat','$desc')");$msg="Aquarium added!";}
        else{$conn->query("UPDATE aquariums SET name='$name',size_liters=$size,price=$price,stock_quantity=$qty,material='$mat',description='$desc' WHERE id=$id");$msg="Updated!";}
    }
    if($action==='delete'&&isAdmin()){$conn->query("DELETE FROM aquariums WHERE id=".(int)$_POST['id']);$msg="Deleted.";$msgType='warning';}
}
$aquariums=$conn->query("SELECT * FROM aquariums ORDER BY size_liters");
?>
<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Aquariums — Uttara Pet Shop</title><link rel="stylesheet" href="../assets/css/style.css"></head><body>
<?php renderSidebar('aquariums'); ?>
<div class="main"><?php pageHeader('🐟 Aquarium Gallery','Fish tanks for sale'); ?>
<?php if($msg): ?><div class="alert alert-<?=$msgType?>"><?=$msg?></div><?php endif; ?>
<div class="section-bar"><h2>All Aquariums</h2><button class="btn btn-primary" onclick="openModal('addModal')">+ Add Aquarium</button></div>
<div class="card"><div class="table-wrap"><table>
<thead><tr><th>#</th><th>Name</th><th>Size</th><th>Material</th><th>Price</th><th>Stock</th><th>Actions</th></tr></thead>
<tbody><?php $i=1;while($r=$aquariums->fetch_assoc()): ?><tr>
<td><?=$i++?></td><td><b style="color:var(--brown-deep)"><?=htmlspecialchars($r['name'])?></b></td>
<td><?=$r['size_liters']?> L</td><td><span class="badge badge-brown"><?=ucfirst($r['material'])?></span></td>
<td style="color:var(--amber);font-weight:600"><?=money($r['price'])?></td>
<td><?=$r['stock_quantity']<=1?'<span class="badge badge-coral">'.$r['stock_quantity'].'</span>':'<span class="badge badge-green">'.$r['stock_quantity'].'</span>'?></td>
<td><button class="btn btn-outline btn-sm" onclick='editA(<?=json_encode($r)?>)'>Edit</button>
<?php if(isAdmin()): ?><form method="POST" style="display:inline" onsubmit="return confirm('Delete?')"><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?=$r['id']?>"><button type="submit" class="btn btn-danger btn-sm">Del</button></form><?php endif; ?></td>
</tr><?php endwhile; ?></tbody></table></div></div>
<div class="modal-overlay" id="addModal"><div class="modal"><div class="modal-header"><span class="modal-title">🐟 Add Aquarium</span><button class="modal-close" onclick="closeModal('addModal')">✕</button></div>
<form method="POST"><input type="hidden" name="action" value="add">
<div class="form-group"><label class="form-label">Name *</label><input type="text" name="name" class="form-control" required placeholder="e.g. Nano Tank 20L"></div>
<div class="form-grid"><div class="form-group"><label class="form-label">Size (Liters)</label><input type="number" name="size_liters" class="form-control" step="0.1"></div><div class="form-group"><label class="form-label">Material</label><select name="material" class="form-control"><option value="glass">Glass</option><option value="acrylic">Acrylic</option><option value="other">Other</option></select></div></div>
<div class="form-grid"><div class="form-group"><label class="form-label">Price (৳) *</label><input type="number" name="price" class="form-control" step="0.01" required></div><div class="form-group"><label class="form-label">Stock</label><input type="number" name="stock_quantity" class="form-control" value="1"></div></div>
<div class="form-group"><label class="form-label">Description</label><textarea name="description" class="form-control" rows="2"></textarea></div>
<button type="submit" class="btn btn-primary" style="width:100%;justify-content:center">Add Aquarium</button></form></div></div>
<div class="modal-overlay" id="editModal"><div class="modal"><div class="modal-header"><span class="modal-title">Edit Aquarium</span><button class="modal-close" onclick="closeModal('editModal')">✕</button></div>
<form method="POST"><input type="hidden" name="action" value="edit"><input type="hidden" name="id" id="e_id">
<div class="form-group"><label class="form-label">Name *</label><input type="text" name="name" id="e_name" class="form-control" required></div>
<div class="form-grid"><div class="form-group"><label class="form-label">Size (L)</label><input type="number" name="size_liters" id="e_size" class="form-control" step="0.1"></div><div class="form-group"><label class="form-label">Material</label><select name="material" id="e_mat" class="form-control"><option value="glass">Glass</option><option value="acrylic">Acrylic</option><option value="other">Other</option></select></div></div>
<div class="form-grid"><div class="form-group"><label class="form-label">Price (৳)</label><input type="number" name="price" id="e_price" class="form-control" step="0.01"></div><div class="form-group"><label class="form-label">Stock</label><input type="number" name="stock_quantity" id="e_qty" class="form-control"></div></div>
<div class="form-group"><label class="form-label">Description</label><textarea name="description" id="e_desc" class="form-control" rows="2"></textarea></div>
<button type="submit" class="btn btn-amber" style="width:100%;justify-content:center">Update</button></form></div></div>
<script>
function openModal(id){document.getElementById(id).classList.add('open');}function closeModal(id){document.getElementById(id).classList.remove('open');}
function editA(d){document.getElementById('e_id').value=d.id;document.getElementById('e_name').value=d.name;document.getElementById('e_size').value=d.size_liters;document.getElementById('e_mat').value=d.material;document.getElementById('e_price').value=d.price;document.getElementById('e_qty').value=d.stock_quantity;document.getElementById('e_desc').value=d.description||'';openModal('editModal');}
function toggleSidebar(){document.getElementById('sidebar').classList.toggle('open');}
</script></div></body></html>
