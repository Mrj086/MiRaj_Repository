<?php
require_once '../includes/config.php';
require_once '../includes/layout.php';
requireLogin(); if(!isAdmin()){header("Location: dashboard.php");exit();}

$msg='';$msgType='success';

// Mark as received
if(isset($_POST['mark_received'])) {
    $po_id=(int)$_POST['po_id'];
    $arrival=clean($_POST['arrival_date']);
    $conn->query("UPDATE purchase_orders SET status='received',arrival_date='$arrival' WHERE id=$po_id");
    // Update stock for each item
    $items=$conn->query("SELECT * FROM purchase_order_items WHERE po_id=$po_id");
    while($item=$items->fetch_assoc()) {
        $tbl=$item['item_type']==='animal'?'animals':($item['item_type']==='aquarium'?'aquariums':'products');
        $qty=(int)$item['quantity_ordered'];
        $iid=(int)$item['item_id'];
        $conn->query("UPDATE $tbl SET stock_quantity=stock_quantity+$qty WHERE id=$iid");
        $conn->query("UPDATE purchase_order_items SET quantity_received=$qty WHERE id={$item['id']}");
    }
    // Notify
    $po=$conn->query("SELECT po_number,supplier_id FROM purchase_orders WHERE id=$po_id")->fetch_assoc();
    createNotification($conn,'stock_received',"📦 Stock Received: {$po['po_number']}","Purchase order {$po['po_number']} has been received and stock updated.",'pages/purchases.php');
    $msg="Stock received and inventory updated!";
}

// Add new PO
if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['create_po'])) {
    $supplier_id=(int)$_POST['supplier_id'];
    $order_date =clean($_POST['order_date']);
    $exp_arrival=clean($_POST['expected_arrival']);
    $pay_method =clean($_POST['payment_method']);
    $pay_ref    =clean($_POST['payment_ref']??'');
    $notes      =clean($_POST['notes']??'');
    $po_num     =generatePONumber($conn);
    $uid        =$_SESSION['user_id'];

    $items_raw  =json_decode($_POST['po_items'],true);
    if(!empty($items_raw)) {
        $total=0;
        foreach($items_raw as $it) $total+=$it['qty']*$it['price'];
        $conn->query("INSERT INTO purchase_orders (po_number,supplier_id,user_id,status,total_amount,payment_method,payment_ref,order_date,expected_arrival,notes)
            VALUES ('$po_num',$supplier_id,$uid,'ordered',$total,'$pay_method','$pay_ref','$order_date','$exp_arrival','$notes')");
        $po_id=$conn->insert_id;
        foreach($items_raw as $it) {
            $type=clean($it['type']);$iid=(int)$it['id'];$iname=clean($it['name']);
            $qty=(int)$it['qty'];$price=(float)$it['price'];
            $conn->query("INSERT INTO purchase_order_items (po_id,item_type,item_id,item_name,quantity_ordered,unit_price) VALUES ($po_id,'$type',$iid,'$iname',$qty,$price)");
        }
        createNotification($conn,'new_purchase',"📋 New Purchase Order: $po_num","Order placed with supplier for ".money($total).".",'pages/purchases.php');
        $msg="Purchase Order $po_num created!";
    }
}

$pos=$conn->query("SELECT po.*,s.name sup_name,u.full_name created_by FROM purchase_orders po LEFT JOIN suppliers s ON po.supplier_id=s.id LEFT JOIN users u ON po.user_id=u.id ORDER BY po.created_at DESC");
$suppliers=$conn->query("SELECT * FROM suppliers ORDER BY name");

// All items for PO search
$allItems=[];
$r=$conn->query("SELECT id,'product' type,name,buying_price price FROM products");
while($row=$r->fetch_assoc()) $allItems[]=$row;
$r=$conn->query("SELECT id,'animal' type,name,buying_price price FROM animals");
while($row=$r->fetch_assoc()) $allItems[]=$row;
$r=$conn->query("SELECT id,'aquarium' type,name,price FROM aquariums");
while($row=$r->fetch_assoc()) $allItems[]=$row;
?>
<!DOCTYPE html><html lang="en"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Purchase Orders — Uttara Pet Shop</title>
<link rel="stylesheet" href="../assets/css/style.css">
<style>
.po-items-list{max-height:220px;overflow-y:auto;border:1.5px solid var(--border-dark);border-radius:8px;background:#fff;display:none;margin-top:6px}
.po-result-item{padding:10px 14px;display:flex;justify-content:space-between;cursor:pointer;border-bottom:1px solid var(--border);transition:background .15s;font-size:13px}
.po-result-item:hover{background:var(--bg-hover)}
.cart-line{display:flex;align-items:center;gap:8px;padding:8px 0;border-bottom:1px solid var(--border);font-size:13px}
.cart-line-qty{width:60px;text-align:center;background:var(--cream);border:1px solid var(--border-dark);border-radius:6px;padding:4px;font-family:'DM Mono'}
.cart-line-price{width:90px;background:var(--cream);border:1px solid var(--border-dark);border-radius:6px;padding:4px;font-family:'DM Mono';text-align:right}
</style>
</head><body>
<?php renderSidebar('purchases'); ?>
<div class="main">
<?php pageHeader('📋 Purchase Orders','Supplier billing & stock arrival tracking'); ?>
<?php if($msg): ?><div class="alert alert-<?=$msgType?>"><?=$msg?></div><?php endif; ?>

<div class="section-bar">
    <h2>All Purchase Orders</h2>
    <button class="btn btn-primary" onclick="openModal('createPOModal')">+ New Purchase Order</button>
</div>

<div class="card">
<div class="table-wrap"><table>
<thead><tr><th>PO Number</th><th>Supplier</th><th>Order Date</th><th>Expected Arrival</th><th>Arrival Date</th><th>Total</th><th>Payment</th><th>Status</th><th>Actions</th></tr></thead>
<tbody>
<?php while($po=$pos->fetch_assoc()): ?>
<?php
$statusColors=['ordered'=>'badge-amber','partially_received'=>'badge-blue','received'=>'badge-green','cancelled'=>'badge-coral'];
$sc=$statusColors[$po['status']]??'badge-sand';
$overdue=($po['status']==='ordered' && $po['expected_arrival'] && strtotime($po['expected_arrival'])<time());
?>
<tr class="<?=$overdue?'low-stock-row':''?>">
    <td><span style="font-family:'DM Mono';color:var(--forest-mid)"><?=$po['po_number']?></span></td>
    <td><b><?=htmlspecialchars($po['sup_name']??'—')?></b></td>
    <td><?=$po['order_date']?></td>
    <td><?=$po['expected_arrival']??'—'?><?=$overdue?' <span class="badge badge-coral">Overdue!</span>':''?></td>
    <td><?=$po['arrival_date']??'<span style="color:var(--text-muted)">Pending</span>'?></td>
    <td><b style="color:var(--amber)"><?=money($po['total_amount'])?></b></td>
    <td style="font-size:12px"><?=paymentLabel($po['payment_method'])?><?=$po['payment_ref']?"<br><small style='color:var(--text-muted)'>{$po['payment_ref']}</small>":''?></td>
    <td><span class="badge <?=$sc?>"><?=ucfirst(str_replace('_',' ',$po['status']))?></span></td>
    <td>
        <button class="btn btn-outline btn-sm" onclick="viewPOItems(<?=$po['id']?>)">Items</button>
        <?php if($po['status']==='ordered'||$po['status']==='partially_received'): ?>
        <button class="btn btn-primary btn-sm" onclick="openReceiveModal(<?=$po['id']?>, '<?=$po['po_number']?>')">Receive Stock</button>
        <?php endif; ?>
    </td>
</tr>
<?php endwhile; ?>
</tbody>
</table></div>
</div>

<!-- Create PO Modal -->
<div class="modal-overlay" id="createPOModal">
<div class="modal modal-lg">
    <div class="modal-header"><span class="modal-title">📋 New Purchase Order</span><button class="modal-close" onclick="closeModal('createPOModal')">✕</button></div>
    <form method="POST">
        <input type="hidden" name="create_po" value="1">
        <input type="hidden" name="po_items" id="poItemsData">

        <div class="form-grid">
            <div class="form-group"><label class="form-label">Supplier *</label>
                <select name="supplier_id" class="form-control" required>
                    <option value="">-- Select Supplier --</option>
                    <?php $suppliers->data_seek(0);while($s=$suppliers->fetch_assoc()): ?>
                    <option value="<?=$s['id']?>"><?=htmlspecialchars($s['name'])?> — <?=$s['phone']?></option>
                    <?php endwhile; ?>
                </select></div>
            <div class="form-group"><label class="form-label">Order Date *</label>
                <input type="date" name="order_date" class="form-control" value="<?=date('Y-m-d')?>" required></div>
        </div>
        <div class="form-grid">
            <div class="form-group"><label class="form-label">Expected Arrival</label>
                <input type="date" name="expected_arrival" class="form-control"></div>
            <div class="form-group"><label class="form-label">Payment Method</label>
                <select name="payment_method" class="form-control">
                    <option value="cash">💵 Cash</option>
                    <option value="bank_transfer">🏦 Bank Transfer</option>
                    <option value="bkash_personal">📱 bKash Personal</option>
                    <option value="bkash_merchant">🏪 bKash Merchant</option>
                    <option value="nagad">📲 Nagad</option>
                    <option value="rocket">🚀 Rocket</option>
                    <option value="credit">📋 Credit (Pay Later)</option>
                </select></div>
        </div>
        <div class="form-group"><label class="form-label">Payment Reference</label>
            <input type="text" name="payment_ref" class="form-control" placeholder="Transaction ID / Reference No."></div>

        <!-- Item Search -->
        <div class="form-group">
            <label class="form-label">Add Items to Order</label>
            <input type="text" id="poSearch" class="form-control" placeholder="Search products or animals to order..." oninput="searchPOItems(this.value)" autocomplete="off">
            <div class="po-items-list" id="poResults"></div>
        </div>

        <!-- Cart -->
        <div id="poCartWrap" style="display:none;margin-bottom:16px">
            <label class="form-label">Order Items</label>
            <div id="poCart"></div>
            <div style="display:flex;justify-content:space-between;padding:10px 0;border-top:2px solid var(--border);font-weight:600;font-size:14px">
                <span>Total Order Value</span>
                <span id="poTotal" style="color:var(--amber);font-family:'DM Mono'">৳ 0.00</span>
            </div>
        </div>

        <div class="form-group"><label class="form-label">Notes</label>
            <textarea name="notes" class="form-control" rows="2" placeholder="Special instructions to supplier..."></textarea></div>

        <button type="button" onclick="submitPO()" class="btn btn-primary" style="width:100%;justify-content:center">Create Purchase Order</button>
    </form>
</div>
</div>

<!-- Receive Stock Modal -->
<div class="modal-overlay" id="receiveModal">
<div class="modal">
    <div class="modal-header"><span class="modal-title">📦 Receive Stock</span><button class="modal-close" onclick="closeModal('receiveModal')">✕</button></div>
    <form method="POST">
        <input type="hidden" name="mark_received" value="1">
        <input type="hidden" name="po_id" id="receive_po_id">
        <p style="color:var(--text-mid);margin-bottom:16px;font-size:13px">Confirming receipt will automatically add all ordered quantities to stock.</p>
        <div class="form-group"><label class="form-label">Actual Arrival Date *</label>
            <input type="date" name="arrival_date" class="form-control" value="<?=date('Y-m-d')?>" required></div>
        <div id="receive_po_info" style="padding:12px;background:var(--cream);border-radius:8px;margin-bottom:16px;font-size:13px;color:var(--text-mid)"></div>
        <button type="submit" class="btn btn-primary" style="width:100%;justify-content:center">✅ Confirm Stock Received</button>
    </form>
</div>
</div>

<!-- View Items Modal -->
<div class="modal-overlay" id="viewItemsModal">
<div class="modal">
    <div class="modal-header"><span class="modal-title" id="viewItemsTitle">PO Items</span><button class="modal-close" onclick="closeModal('viewItemsModal')">✕</button></div>
    <div id="viewItemsContent"></div>
</div>
</div>

<script>
const allItems = <?=json_encode($allItems)?>;
let poCart = [];

function searchPOItems(q) {
    const box=document.getElementById('poResults');
    if(!q.trim()){box.style.display='none';return;}
    const res=allItems.filter(i=>i.name.toLowerCase().includes(q.toLowerCase())).slice(0,8);
    if(!res.length){box.innerHTML='<p style="padding:10px;color:var(--text-muted)">Not found</p>';box.style.display='block';return;}
    box.style.display='block';
    box.innerHTML=res.map(i=>`<div class="po-result-item" onclick='addToPOCart(${JSON.stringify(i)})'>
        <span>${i.name} <span class="badge badge-sand">${i.type}</span></span>
        <span style="color:var(--amber);font-family:'DM Mono'">৳${parseFloat(i.price).toFixed(2)}</span>
    </div>`).join('');
}

function addToPOCart(item) {
    if(poCart.find(c=>c.id==item.id&&c.type===item.type)) return;
    poCart.push({id:item.id,type:item.type,name:item.name,price:parseFloat(item.price),qty:1});
    document.getElementById('poSearch').value='';
    document.getElementById('poResults').style.display='none';
    renderPOCart();
}

function removePOItem(i){poCart.splice(i,1);renderPOCart();}
function updatePOQty(i,v){poCart[i].qty=Math.max(1,parseInt(v)||1);renderPOCart();}
function updatePOPrice(i,v){poCart[i].price=parseFloat(v)||0;renderPOCart();}

function renderPOCart(){
    const wrap=document.getElementById('poCartWrap');
    if(!poCart.length){wrap.style.display='none';return;}
    wrap.style.display='block';
    document.getElementById('poCart').innerHTML=poCart.map((item,i)=>`
    <div class="cart-line">
        <div style="flex:1;font-weight:500;color:var(--brown-deep)">${item.name}<br><span class="badge badge-sand" style="font-size:10px">${item.type}</span></div>
        <div style="display:flex;align-items:center;gap:6px">
            <span style="font-size:11px;color:var(--text-muted)">Qty:</span>
            <input type="number" class="cart-line-qty" value="${item.qty}" min="1" onchange="updatePOQty(${i},this.value)">
            <span style="font-size:11px;color:var(--text-muted)">Price:</span>
            <input type="number" class="cart-line-price" value="${item.price.toFixed(2)}" min="0" step="0.01" onchange="updatePOPrice(${i},this.value)">
            <button type="button" onclick="removePOItem(${i})" style="background:none;border:none;color:var(--coral);cursor:pointer;font-size:18px">×</button>
        </div>
    </div>`).join('');
    const total=poCart.reduce((s,i)=>s+i.qty*i.price,0);
    document.getElementById('poTotal').textContent='৳ '+total.toFixed(2);
}

function submitPO(){
    if(!poCart.length){alert('Add at least one item!');return;}
    document.getElementById('poItemsData').value=JSON.stringify(poCart);
    document.querySelector('[name="create_po"]').closest('form').submit();
}

function openReceiveModal(id,poNum){
    document.getElementById('receive_po_id').value=id;
    document.getElementById('receive_po_info').innerHTML='<b>PO: '+poNum+'</b><br>All items will be added to stock inventory.';
    openModal('receiveModal');
}

function viewPOItems(poId){
    fetch('get_po_items.php?po_id='+poId)
    .then(r=>r.text()).then(html=>{
        document.getElementById('viewItemsTitle').textContent='PO Items #'+poId;
        document.getElementById('viewItemsContent').innerHTML=html;
        openModal('viewItemsModal');
    });
}

function openModal(id){document.getElementById(id).classList.add('open');}
function closeModal(id){document.getElementById(id).classList.remove('open');}
function toggleSidebar(){document.getElementById('sidebar').classList.toggle('open');}
</script>
</body></html>
