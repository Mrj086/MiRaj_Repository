<?php
require_once '../includes/config.php';
require_once '../includes/layout.php';
requireLogin();

// Handle quick-add customer via AJAX
if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['ajax_add_customer'])) {
    $name  = clean($_POST['name']);
    $phone = clean($_POST['phone']);
    $email = clean($_POST['email']);
    $addr  = clean($_POST['address']);
    if ($name) {
        $conn->query("INSERT INTO customers (name,phone,email,address) VALUES ('$name','$phone','$email','$addr')");
        $new_id = $conn->insert_id;
        echo json_encode(['success'=>true,'id'=>$new_id,'name'=>$name,'phone'=>$phone]);
    } else {
        echo json_encode(['success'=>false,'error'=>'Name is required']);
    }
    exit();
}

// Handle finalize sale
if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['finalize'])) {
    $customer_id = (int)$_POST['customer_id'];
    $discount    = (float)$_POST['discount'];
    $payment     = clean($_POST['payment_method']);
    $pay_ref     = clean($_POST['payment_ref']??'');
    $notes       = clean($_POST['notes']);
    $items       = json_decode($_POST['cart_data'],true);

    if (!empty($items)) {
        $subtotal=0; foreach($items as $item) $subtotal+=$item['qty']*$item['price'];
        $total   = max(0,$subtotal-$discount);
        $invoice = generateInvoiceNo($conn);
        $uid     = $_SESSION['user_id'];

        $conn->begin_transaction();
        try {
            $stmt=$conn->prepare("INSERT INTO sales (invoice_no,customer_id,user_id,subtotal,discount,total,payment_method,payment_ref,notes) VALUES (?,?,?,?,?,?,?,?,?)");
            $stmt->bind_param("siidddsss",$invoice,$customer_id,$uid,$subtotal,$discount,$total,$payment,$pay_ref,$notes);
            $stmt->execute();
            $sale_id=$conn->insert_id;

            foreach($items as $item) {
                $type =clean($item['type']); $iid=(int)$item['id'];
                $iname=clean($item['name']); $qty=(int)$item['qty'];
                $price=(float)$item['price']; $line=$qty*$price;
                $conn->query("INSERT INTO sale_items (sale_id,item_type,item_id,item_name,quantity,unit_price,total_price) VALUES ($sale_id,'$type',$iid,'$iname',$qty,$price,$line)");
                $tbl=$type==='animal'?'animals':($type==='aquarium'?'aquariums':'products');
                $conn->query("UPDATE $tbl SET stock_quantity=stock_quantity-$qty WHERE id=$iid");
            }

            // Notify admin
            $cashier = $_SESSION['full_name'];
            createNotification($conn,'new_sale',"🧾 New Sale: $invoice","$cashier completed a sale of ".money($total)." via ".paymentLabel($payment).".",'pages/invoice.php?id='.$sale_id);
            checkLowStock($conn);

            $conn->commit();
            header("Location: invoice.php?id=$sale_id&new=1"); exit();
        } catch(Exception $e) {
            $conn->rollback();
            $error="Sale failed: ".$e->getMessage();
        }
    } else { $error="Cart is empty!"; }
}

// Fetch items + customers
$allItems=[];
$r=$conn->query("SELECT id,'product' type,name,selling_price price,stock_quantity FROM products WHERE stock_quantity>0");
while($row=$r->fetch_assoc()) $allItems[]=$row;
$r=$conn->query("SELECT id,'animal' type,name,selling_price price,stock_quantity FROM animals WHERE stock_quantity>0");
while($row=$r->fetch_assoc()) $allItems[]=$row;
$r=$conn->query("SELECT id,'aquarium' type,name,price,stock_quantity FROM aquariums WHERE stock_quantity>0");
while($row=$r->fetch_assoc()) $allItems[]=$row;

$customers=$conn->query("SELECT * FROM customers ORDER BY name");
?>
<!DOCTYPE html><html lang="en"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>New Sale — Uttara Pet Shop</title>
<link rel="stylesheet" href="../assets/css/style.css">
<style>
.pos-layout{display:grid;grid-template-columns:1fr 380px;gap:20px}
.item-results{max-height:260px;overflow-y:auto;border:1.5px solid var(--border-dark);border-radius:var(--radius-sm);background:#fff;margin-top:8px;display:none}
.result-item{padding:11px 14px;display:flex;justify-content:space-between;align-items:center;cursor:pointer;border-bottom:1px solid var(--border);transition:background .15s}
.result-item:hover{background:var(--bg-hover)}
.cart-item{display:flex;align-items:center;gap:10px;padding:10px 0;border-bottom:1px solid var(--border)}
.cart-qty{width:52px;text-align:center;background:var(--cream);border:1.5px solid var(--border-dark);border-radius:6px;padding:5px;font-family:'DM Mono';color:var(--text-dark)}
.total-row{display:flex;justify-content:space-between;padding:7px 0;font-size:13px;color:var(--text-mid)}
.grand-total{font-family:'DM Mono';font-size:24px;font-weight:500;color:var(--forest)}
.pay-grid{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:4px}
.pay-btn{padding:9px 10px;border:2px solid var(--border);border-radius:8px;cursor:pointer;font-size:12.5px;text-align:center;background:var(--cream);transition:all .2s;font-family:'DM Sans'}
.pay-btn:hover{border-color:var(--forest-mid)}
.pay-btn.active{border-color:var(--forest);background:var(--forest-glow);color:var(--forest);font-weight:600}
@media(max-width:900px){.pos-layout{grid-template-columns:1fr}}
</style>
</head><body>
<?php renderSidebar('new_sale'); ?>
<div class="main">
<?php pageHeader('🛒 New Sale','Create a new invoice'); ?>
<?php if(isset($error)): ?><div class="alert alert-danger"><?=$error?></div><?php endif; ?>

<form method="POST" id="saleForm">
<div class="pos-layout">

<!-- LEFT: Search + Cart -->
<div>
    <div class="card" style="margin-bottom:16px">
        <div class="card-title">Search & Add Items</div>
        <input type="text" id="itemSearch" class="form-control" placeholder="Type to search animals, fish, products, aquariums..." oninput="searchItems(this.value)" autocomplete="off">
        <div class="item-results" id="searchResults"></div>
    </div>
    <div class="card">
        <div class="card-title">🛒 Cart Items</div>
        <div id="cartItems"><p style="color:var(--text-muted);padding:16px 0;font-size:13px">No items yet. Search above to add.</p></div>
    </div>
</div>

<!-- RIGHT: Billing -->
<div>
    <!-- Customer -->
    <div class="card" style="margin-bottom:14px">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px">
            <div class="card-title" style="margin:0;border:none;padding:0">👤 Customer</div>
            <button type="button" class="btn btn-outline btn-sm" onclick="openModal('newCustomerModal')">+ New</button>
        </div>
        <select name="customer_id" id="customerSelect" class="form-control">
            <option value="1">Walk-in Customer</option>
            <?php $customers->data_seek(0); while($c=$customers->fetch_assoc()): ?>
            <?php if($c['id']==1) continue; ?>
            <option value="<?=$c['id']?>"><?=htmlspecialchars($c['name'])?><?=$c['phone']?' — '.$c['phone']:''?></option>
            <?php endwhile; ?>
        </select>
    </div>

    <!-- Payment -->
    <div class="card" style="margin-bottom:14px">
        <div class="card-title">💳 Payment Method</div>
        <input type="hidden" name="payment_method" id="paymentMethod" value="cash">
        <div class="pay-grid">
            <button type="button" class="pay-btn active" onclick="selectPayment('cash',this)">💵 Cash</button>
            <button type="button" class="pay-btn" onclick="selectPayment('card',this)">💳 Card</button>
            <button type="button" class="pay-btn" onclick="selectPayment('bkash_personal',this)">📱 bKash Personal</button>
            <button type="button" class="pay-btn" onclick="selectPayment('bkash_merchant',this)">🏪 bKash Merchant</button>
            <button type="button" class="pay-btn" onclick="selectPayment('nagad',this)">📲 Nagad</button>
            <button type="button" class="pay-btn" onclick="selectPayment('rocket',this)">🚀 Rocket</button>
        </div>
        <div id="refField" style="display:none;margin-top:10px">
            <label class="form-label">Transaction / Reference No.</label>
            <input type="text" name="payment_ref" class="form-control" placeholder="e.g. 01XXXXXXXXXX or TXN123">
        </div>
    </div>

    <!-- Billing Summary -->
    <div class="card">
        <div class="card-title">🧾 Billing Summary</div>
        <div class="total-row"><span>Subtotal</span><span id="subtotalDisplay">৳ 0.00</span></div>
        <div class="total-row">
            <span>Discount (৳)</span>
            <input type="number" name="discount" id="discountInput" style="width:100px;text-align:right" class="form-control" value="0" min="0" step="0.01" oninput="updateTotals()">
        </div>
        <hr style="border:none;border-top:2px solid var(--border);margin:10px 0">
        <div class="total-row" style="font-size:16px;font-weight:600;color:var(--brown-deep)">
            <span>Grand Total</span>
            <span class="grand-total" id="totalDisplay">৳ 0.00</span>
        </div>
        <div class="form-group" style="margin-top:14px">
            <label class="form-label">Notes (optional)</label>
            <textarea name="notes" class="form-control" rows="2" placeholder="Special instructions..."></textarea>
        </div>
        <input type="hidden" name="cart_data" id="cartData">
        <input type="hidden" name="finalize" value="1">
        <button type="button" onclick="finalizeSale()" class="btn btn-primary" style="width:100%;justify-content:center;padding:13px;font-size:15px">
            ✅ Complete Sale & Print Invoice
        </button>
    </div>
</div>
</div>
</form>

<!-- New Customer Modal -->
<div class="modal-overlay" id="newCustomerModal">
<div class="modal">
    <div class="modal-header">
        <span class="modal-title">👤 Add New Customer</span>
        <button class="modal-close" onclick="closeModal('newCustomerModal')">✕</button>
    </div>
    <div class="form-group"><label class="form-label">Full Name *</label><input type="text" id="nc_name" class="form-control" placeholder="Customer name" required></div>
    <div class="form-grid">
        <div class="form-group"><label class="form-label">Phone *</label><input type="text" id="nc_phone" class="form-control" placeholder="01XXXXXXXXX"></div>
        <div class="form-group"><label class="form-label">Email</label><input type="email" id="nc_email" class="form-control" placeholder="optional"></div>
    </div>
    <div class="form-group"><label class="form-label">Address</label><textarea id="nc_addr" class="form-control" rows="2"></textarea></div>
    <div id="nc_error" class="alert alert-danger" style="display:none"></div>
    <button type="button" onclick="saveNewCustomer()" class="btn btn-primary" style="width:100%;justify-content:center">Save & Select Customer</button>
</div>
</div>

<script>
const allItems = <?=json_encode($allItems)?>;
let cart = [];

function searchItems(q) {
    const box=document.getElementById('searchResults');
    if(!q.trim()){box.style.display='none';return;}
    const results=allItems.filter(i=>i.name.toLowerCase().includes(q.toLowerCase())).slice(0,10);
    if(!results.length){box.innerHTML='<p style="padding:12px;color:var(--text-muted)">No items found</p>';box.style.display='block';return;}
    const colors={animal:'badge-green',aquarium:'badge-amber',product:'badge-sand'};
    box.style.display='block';
    box.innerHTML=results.map(i=>`<div class="result-item" onclick='addToCart(${JSON.stringify(i)})'>
        <div><div style="font-weight:500;color:var(--brown-deep)">${i.name}</div>
        <span class="badge ${colors[i.type]||'badge-sand'}" style="margin-top:3px">${i.type}</span></div>
        <div style="text-align:right"><div style="color:var(--amber);font-family:'DM Mono';font-weight:500">৳${parseFloat(i.price).toFixed(2)}</div>
        <div style="font-size:11px;color:var(--text-muted)">Stock: ${i.stock_quantity}</div></div>
    </div>`).join('');
}

function addToCart(item) {
    const ex=cart.find(c=>c.id==item.id&&c.type===item.type);
    if(ex){if(ex.qty<item.stock_quantity)ex.qty++;else{alert('Not enough stock!');return;}}
    else cart.push({id:item.id,type:item.type,name:item.name,price:parseFloat(item.price),qty:1,maxQty:item.stock_quantity});
    document.getElementById('itemSearch').value='';
    document.getElementById('searchResults').style.display='none';
    renderCart();
}
function removeFromCart(i){cart.splice(i,1);renderCart();}
function updateQty(i,v){cart[i].qty=Math.max(1,Math.min(parseInt(v)||1,cart[i].maxQty));renderCart();}

function renderCart(){
    const box=document.getElementById('cartItems');
    if(!cart.length){box.innerHTML='<p style="color:var(--text-muted);font-size:13px;padding:16px 0">No items added yet.</p>';updateTotals();return;}
    box.innerHTML=cart.map((item,i)=>`<div class="cart-item">
        <div style="flex:1"><div style="font-weight:500;color:var(--brown-deep)">${item.name}</div>
        <div style="font-size:11px;color:var(--text-muted)">৳${item.price.toFixed(2)} each</div></div>
        <input type="number" class="cart-qty" value="${item.qty}" min="1" max="${item.maxQty}" onchange="updateQty(${i},this.value)">
        <div style="min-width:85px;text-align:right;color:var(--amber);font-family:'DM Mono';font-weight:500">৳${(item.price*item.qty).toFixed(2)}</div>
        <button type="button" onclick="removeFromCart(${i})" style="background:none;border:none;color:var(--coral);cursor:pointer;font-size:20px;padding:0 4px">×</button>
    </div>`).join('');
    updateTotals();
}

function updateTotals(){
    const sub=cart.reduce((s,i)=>s+i.price*i.qty,0);
    const dis=parseFloat(document.getElementById('discountInput').value)||0;
    document.getElementById('subtotalDisplay').textContent='৳ '+sub.toFixed(2);
    document.getElementById('totalDisplay').textContent='৳ '+Math.max(0,sub-dis).toFixed(2);
}

function selectPayment(method,btn){
    document.getElementById('paymentMethod').value=method;
    document.querySelectorAll('.pay-btn').forEach(b=>b.classList.remove('active'));
    btn.classList.add('active');
    const needRef=['card','bkash_personal','bkash_merchant','nagad','rocket'];
    document.getElementById('refField').style.display=needRef.includes(method)?'block':'none';
}

function finalizeSale(){
    if(!cart.length){alert('Cart is empty! Add items first.');return;}
    document.getElementById('cartData').value=JSON.stringify(cart);
    document.getElementById('saleForm').submit();
}

// Add new customer via AJAX
function saveNewCustomer(){
    const name=document.getElementById('nc_name').value.trim();
    const phone=document.getElementById('nc_phone').value.trim();
    const email=document.getElementById('nc_email').value.trim();
    const addr=document.getElementById('nc_addr').value.trim();
    const errDiv=document.getElementById('nc_error');
    if(!name){errDiv.textContent='Name is required!';errDiv.style.display='block';return;}
    errDiv.style.display='none';
    const fd=new FormData();
    fd.append('ajax_add_customer','1');fd.append('name',name);fd.append('phone',phone);fd.append('email',email);fd.append('address',addr);
    fetch('new_sale.php',{method:'POST',body:fd})
    .then(r=>r.json()).then(data=>{
        if(data.success){
            const sel=document.getElementById('customerSelect');
            const opt=document.createElement('option');
            opt.value=data.id;opt.text=data.name+(data.phone?' — '+data.phone:'');
            opt.selected=true;
            sel.appendChild(opt);
            closeModal('newCustomerModal');
            document.getElementById('nc_name').value='';document.getElementById('nc_phone').value='';
            document.getElementById('nc_email').value='';document.getElementById('nc_addr').value='';
        } else { errDiv.textContent=data.error||'Error saving customer.';errDiv.style.display='block'; }
    });
}

function openModal(id){document.getElementById(id).classList.add('open');}
function closeModal(id){document.getElementById(id).classList.remove('open');}
function toggleSidebar(){document.getElementById('sidebar').classList.toggle('open');}
</script>
</body></html>
