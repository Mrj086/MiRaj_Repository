<?php
require_once '../includes/config.php'; require_once '../includes/layout.php'; requireLogin(); if(!isAdmin()){header("Location: dashboard.php");exit();}
$msg='';$msgType='success';
if($_SERVER['REQUEST_METHOD']==='POST'){
    $action=$_POST['action']??'';
    if($action==='add'||$action==='edit'){
        $id=(int)($_POST['id']??0);$name=clean($_POST['name']);$cp=clean($_POST['contact_person']);$ph=clean($_POST['phone']);$em=clean($_POST['email']);$addr=clean($_POST['address']);
        if($action==='add'){$conn->query("INSERT INTO suppliers (name,contact_person,phone,email,address) VALUES ('$name','$cp','$ph','$em','$addr')");$msg="Supplier added!";}
        else{$conn->query("UPDATE suppliers SET name='$name',contact_person='$cp',phone='$ph',email='$em',address='$addr' WHERE id=$id");$msg="Updated!";}
    }
    if($action==='delete'){$conn->query("DELETE FROM suppliers WHERE id=".(int)$_POST['id']);$msg="Deleted.";$msgType='warning';}
}
$suppliers=$conn->query("SELECT s.*,(SELECT COUNT(*) FROM purchase_orders WHERE supplier_id=s.id) total_pos,(SELECT COALESCE(SUM(total_amount),0) FROM purchase_orders WHERE supplier_id=s.id) total_value FROM suppliers s ORDER BY s.name");
?>
<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Suppliers — Uttara Pet Shop</title><link rel="stylesheet" href="../assets/css/style.css"></head><body>
<?php renderSidebar('suppliers'); ?>
<div class="main"><?php pageHeader('🚚 Suppliers','Manage your suppliers'); ?>
<?php if($msg): ?><div class="alert alert-<?=$msgType?>"><?=$msg?></div><?php endif; ?>
<div class="section-bar"><h2>All Suppliers</h2><button class="btn btn-primary" onclick="openModal('addModal')">+ Add Supplier</button></div>
<div class="card"><div class="table-wrap"><table>
<thead><tr><th>#</th><th>Company</th><th>Contact</th><th>Phone</th><th>Email</th><th>Total Orders</th><th>Total Value</th><th>Actions</th></tr></thead>
<tbody><?php $i=1;while($r=$suppliers->fetch_assoc()): ?><tr>
<td><?=$i++?></td><td><b style="color:var(--brown-deep)"><?=htmlspecialchars($r['name'])?></b></td>
<td><?=htmlspecialchars($r['contact_person']??'—')?></td>
<td><a href="tel:<?=$r['phone']?>" style="color:var(--forest)"><?=$r['phone']??'—'?></a></td>
<td style="color:var(--text-muted)"><?=htmlspecialchars($r['email']??'—')?></td>
<td><span class="badge badge-brown"><?=$r['total_pos']?> orders</span></td>
<td style="color:var(--amber);font-weight:600"><?=money($r['total_value'])?></td>
<td>
<a href="purchases.php" class="btn btn-outline btn-sm">View Orders</a>
<button class="btn btn-outline btn-sm" onclick='editS(<?=json_encode($r)?>)'>Edit</button>
<form method="POST" style="display:inline" onsubmit="return confirm('Delete?')"><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?=$r['id']?>"><button type="submit" class="btn btn-danger btn-sm">Del</button></form></td>
</tr><?php endwhile; ?></tbody></table></div></div>
<div class="modal-overlay" id="addModal"><div class="modal"><div class="modal-header"><span class="modal-title">🚚 Add Supplier</span><button class="modal-close" onclick="closeModal('addModal')">✕</button></div>
<form method="POST"><input type="hidden" name="action" value="add">
<div class="form-group"><label class="form-label">Company Name *</label><input type="text" name="name" class="form-control" required></div>
<div class="form-grid"><div class="form-group"><label class="form-label">Contact Person</label><input type="text" name="contact_person" class="form-control"></div><div class="form-group"><label class="form-label">Phone</label><input type="text" name="phone" class="form-control"></div></div>
<div class="form-group"><label class="form-label">Email</label><input type="email" name="email" class="form-control"></div>
<div class="form-group"><label class="form-label">Address</label><textarea name="address" class="form-control" rows="2"></textarea></div>
<button type="submit" class="btn btn-primary" style="width:100%;justify-content:center">Add Supplier</button></form></div></div>
<div class="modal-overlay" id="editModal"><div class="modal"><div class="modal-header"><span class="modal-title">Edit Supplier</span><button class="modal-close" onclick="closeModal('editModal')">✕</button></div>
<form method="POST"><input type="hidden" name="action" value="edit"><input type="hidden" name="id" id="e_id">
<div class="form-group"><label class="form-label">Company Name *</label><input type="text" name="name" id="e_name" class="form-control" required></div>
<div class="form-grid"><div class="form-group"><label class="form-label">Contact</label><input type="text" name="contact_person" id="e_cp" class="form-control"></div><div class="form-group"><label class="form-label">Phone</label><input type="text" name="phone" id="e_ph" class="form-control"></div></div>
<div class="form-group"><label class="form-label">Email</label><input type="email" name="email" id="e_em" class="form-control"></div>
<div class="form-group"><label class="form-label">Address</label><textarea name="address" id="e_addr" class="form-control" rows="2"></textarea></div>
<button type="submit" class="btn btn-amber" style="width:100%;justify-content:center">Update</button></form></div></div>
<script>
function openModal(id){document.getElementById(id).classList.add('open');}function closeModal(id){document.getElementById(id).classList.remove('open');}
function editS(d){document.getElementById('e_id').value=d.id;document.getElementById('e_name').value=d.name;document.getElementById('e_cp').value=d.contact_person||'';document.getElementById('e_ph').value=d.phone||'';document.getElementById('e_em').value=d.email||'';document.getElementById('e_addr').value=d.address||'';openModal('editModal');}
function toggleSidebar(){document.getElementById('sidebar').classList.toggle('open');}
</script></div></body></html>
