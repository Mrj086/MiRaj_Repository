<?php
require_once '../includes/config.php';
require_once '../includes/layout.php';
requireLogin(); if(!isAdmin()){header("Location: dashboard.php");exit();}

// Mark all read
if(isset($_POST['mark_all_read'])) {
    $conn->query("UPDATE notifications SET is_read=1");
    header("Location: notifications.php"); exit();
}
// Mark single read
if(isset($_GET['read'])) {
    $conn->query("UPDATE notifications SET is_read=1 WHERE id=".(int)$_GET['read']);
    header("Location: notifications.php"); exit();
}
// Delete single
if(isset($_GET['delete'])) {
    $conn->query("DELETE FROM notifications WHERE id=".(int)$_GET['delete']);
    header("Location: notifications.php"); exit();
}
// Delete all read
if(isset($_POST['delete_read'])) {
    $conn->query("DELETE FROM notifications WHERE is_read=1");
    header("Location: notifications.php"); exit();
}

$filter  = $_GET['filter']??'all';
$where   = $filter==='unread'?'WHERE is_read=0':($filter==='read'?'WHERE is_read=1':'');
$notifs  = $conn->query("SELECT * FROM notifications $where ORDER BY created_at DESC");
$unread  = getUnreadCount($conn);

$typeIcons=['low_stock'=>'⚠️','new_sale'=>'🧾','new_purchase'=>'📋','stock_received'=>'📦','payment_due'=>'💸','custom'=>'📌'];
?>
<!DOCTYPE html><html lang="en"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Notifications — Uttara Pet Shop</title>
<link rel="stylesheet" href="../assets/css/style.css">
</head><body>
<?php renderSidebar('notifications'); ?>
<div class="main">
<?php pageHeader('🔔 Notifications','System alerts & activity feed'); ?>

<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px;flex-wrap:wrap;gap:10px">
    <div style="display:flex;gap:8px">
        <a href="?filter=all"    class="btn btn-sm <?=$filter==='all'?'btn-primary':'btn-outline'?>">All</a>
        <a href="?filter=unread" class="btn btn-sm <?=$filter==='unread'?'btn-primary':'btn-outline'?>">
            Unread <?=$unread>0?"<span style='background:#fff;color:var(--forest);border-radius:10px;padding:1px 6px;font-size:10px;margin-left:4px'>$unread</span>":''?>
        </a>
        <a href="?filter=read"   class="btn btn-sm <?=$filter==='read'?'btn-primary':'btn-outline'?>">Read</a>
    </div>
    <div style="display:flex;gap:8px">
        <form method="POST" style="display:inline"><button name="mark_all_read" class="btn btn-outline btn-sm">✅ Mark All Read</button></form>
        <form method="POST" style="display:inline" onsubmit="return confirm('Delete all read notifications?')"><button name="delete_read" class="btn btn-danger btn-sm">🗑️ Clear Read</button></form>
    </div>
</div>

<div class="card" style="padding:0;overflow:hidden">
<?php if($notifs->num_rows===0): ?>
    <div style="padding:40px;text-align:center;color:var(--text-muted)">
        <div style="font-size:48px;margin-bottom:12px">🔔</div>
        <div style="font-size:15px">No notifications yet</div>
    </div>
<?php else: ?>
<?php while($n=$notifs->fetch_assoc()):
    $icon=$typeIcons[$n['type']]??'📌';
    $timeAgo=function($dt){
        $diff=time()-strtotime($dt);
        if($diff<60) return 'Just now';
        if($diff<3600) return round($diff/60).' min ago';
        if($diff<86400) return round($diff/3600).' hr ago';
        return date('d M Y, h:i A',strtotime($dt));
    };
?>
<div class="notif-item <?=$n['is_read']==0?'unread':''?>">
    <div class="notif-icon"><?=$icon?></div>
    <div style="flex:1">
        <div class="notif-title"><?=htmlspecialchars($n['title'])?></div>
        <div class="notif-msg"><?=htmlspecialchars($n['message'])?></div>
        <div class="notif-time"><?=$timeAgo($n['created_at'])?></div>
    </div>
    <div style="display:flex;flex-direction:column;gap:6px;flex-shrink:0">
        <?php if(!$n['is_read']): ?>
        <a href="?read=<?=$n['id']?>" class="btn btn-outline btn-sm" title="Mark as read">✓ Read</a>
        <?php endif; ?>
        <?php if($n['link']): ?>
        <a href="<?=htmlspecialchars($n['link'])?>" class="btn btn-primary btn-sm">View →</a>
        <?php endif; ?>
        <a href="?delete=<?=$n['id']?>" class="btn btn-danger btn-sm" onclick="return confirm('Delete?')">🗑️</a>
    </div>
</div>
<?php endwhile; ?>
<?php endif; ?>
</div>
</div>
<script>function toggleSidebar(){document.getElementById('sidebar').classList.toggle('open');}</script>
</body></html>
