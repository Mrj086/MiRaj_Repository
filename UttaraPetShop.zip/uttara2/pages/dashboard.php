<?php
require_once '../includes/config.php';
require_once '../includes/layout.php';
requireLogin();
$stats=getDashboardStats($conn);
$chartData=[];
for($i=6;$i>=0;$i--){$date=date('Y-m-d',strtotime("-$i days"));$r=$conn->query("SELECT COALESCE(SUM(total),0) t FROM sales WHERE DATE(sale_date)='$date'")->fetch_assoc();$chartData[]=['date'=>date('D',strtotime($date)),'total'=>(float)$r['t']];}
$recentSales=$conn->query("SELECT s.*,COALESCE(c.name,'Walk-in') customer,u.full_name cashier FROM sales s LEFT JOIN customers c ON s.customer_id=c.id LEFT JOIN users u ON s.user_id=u.id ORDER BY s.sale_date DESC LIMIT 8");
$lowStock=$conn->query("(SELECT 'Product' t,name,stock_quantity,low_stock_alert FROM products WHERE stock_quantity<=low_stock_alert) UNION (SELECT 'Animal' t,name,stock_quantity,low_stock_alert FROM animals WHERE stock_quantity<=low_stock_alert) ORDER BY stock_quantity ASC LIMIT 6");
$pendingPOs=$conn->query("SELECT COUNT(*) c FROM purchase_orders WHERE status='ordered'")->fetch_assoc()['c'];
?>
<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Dashboard — Uttara Pet Shop</title><link rel="stylesheet" href="../assets/css/style.css"><script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.0/chart.umd.min.js"></script></head><body>
<?php renderSidebar('dashboard'); ?>
<div class="main">
<?php pageHeader("Welcome, ".$_SESSION['full_name']." 🐾", date('l, d F Y')); ?>
<div class="stats-grid">
<div class="stat-card green"><div class="s-icon">💰</div><div class="s-label">Today's Sales</div><div class="s-val"><?=money($stats['today_sales'])?></div></div>
<div class="stat-card amber"><div class="s-icon">📅</div><div class="s-label">This Month</div><div class="s-val"><?=money($stats['month_sales'])?></div></div>
<div class="stat-card brown"><div class="s-icon">🐾</div><div class="s-label">Animals</div><div class="s-val"><?=$stats['total_animals']?></div></div>
<div class="stat-card brown"><div class="s-icon">📦</div><div class="s-label">Products</div><div class="s-val"><?=$stats['total_products']?></div></div>
<div class="stat-card coral"><div class="s-icon">⚠️</div><div class="s-label">Low Stock</div><div class="s-val"><?=$stats['low_stock']+$stats['low_animals']?></div><div class="s-sub">Need restocking</div></div>
<div class="stat-card green"><div class="s-icon">👥</div><div class="s-label">Customers</div><div class="s-val"><?=$stats['total_customers']?></div></div>
<div class="stat-card amber"><div class="s-icon">🧾</div><div class="s-label">Invoices</div><div class="s-val"><?=$stats['total_sales']?></div></div>
<?php if(isAdmin()): ?><div class="stat-card coral"><div class="s-icon">🔔</div><div class="s-label">Notifications</div><div class="s-val"><?=$stats['unread_notifs']?></div><div class="s-sub"><a href="notifications.php" style="color:var(--coral)">View all</a></div></div><?php endif; ?>
</div>
<div style="display:grid;grid-template-columns:2fr 1fr;gap:20px;margin-bottom:24px">
<div class="card"><div class="card-title">📈 Sales — Last 7 Days</div><canvas id="salesChart" height="110"></canvas></div>
<div class="card"><div class="card-title">⚠️ Low Stock Alert</div>
<?php if($lowStock->num_rows===0): ?><p style="color:var(--forest);font-size:13px;padding:12px 0">✅ All stock levels healthy!</p>
<?php else: ?><table><thead><tr><th>Item</th><th>Type</th><th>Qty</th></tr></thead><tbody>
<?php while($r=$lowStock->fetch_assoc()): ?><tr class="low-stock-row"><td><?=htmlspecialchars($r['name'])?></td><td><span class="badge badge-coral"><?=$r['t']?></span></td><td><b><?=$r['stock_quantity']?></b></td></tr><?php endwhile; ?>
</tbody></table><?php endif; ?></div></div>
<div class="card"><div class="section-bar"><h2>🧾 Recent Sales</h2><a href="sales.php" class="btn btn-outline btn-sm">View All →</a></div>
<div class="table-wrap"><table><thead><tr><th>Invoice</th><th>Customer</th><th>Payment</th><th>Total</th><th>Date</th></tr></thead><tbody>
<?php while($r=$recentSales->fetch_assoc()): ?><tr>
<td><span style="font-family:'DM Mono';color:var(--forest-mid)"><?=$r['invoice_no']?></span></td>
<td><?=htmlspecialchars($r['customer'])?></td>
<td><span class="badge badge-green"><?=paymentLabel($r['payment_method'])?></span></td>
<td><b style="color:var(--amber)"><?=money($r['total'])?></b></td>
<td style="color:var(--text-muted)"><?=date('d M, h:i A',strtotime($r['sale_date']))?></td>
</tr><?php endwhile; ?>
<?php if($stats['total_sales']==0): ?><tr><td colspan="5" style="text-align:center;padding:28px;color:var(--text-muted)">No sales yet. <a href="new_sale.php" style="color:var(--forest)">Create first sale →</a></td></tr><?php endif; ?>
</tbody></table></div></div>
</div>
<script>
const data=<?=json_encode($chartData)?>;
new Chart(document.getElementById('salesChart'),{type:'bar',data:{labels:data.map(d=>d.date),datasets:[{data:data.map(d=>d.total),backgroundColor:'rgba(45,80,22,0.15)',borderColor:'#3d6b20',borderWidth:2,borderRadius:8}]},options:{responsive:true,plugins:{legend:{display:false}},scales:{x:{grid:{color:'rgba(196,168,130,0.3)'},ticks:{color:'#a07850'}},y:{grid:{color:'rgba(196,168,130,0.3)'},ticks:{color:'#a07850'}}}}});
function toggleSidebar(){document.getElementById('sidebar').classList.toggle('open');}
</script></body></html>
