<?php
require_once '../includes/config.php';
require_once '../includes/layout.php';
requireLogin();
$id  = (int)($_GET['id']??0);
$new = isset($_GET['new']); // came directly from a sale
$sale=$conn->query("SELECT s.*,u.full_name cashier,c.name customer_name,c.phone customer_phone FROM sales s LEFT JOIN users u ON s.user_id=u.id LEFT JOIN customers c ON s.customer_id=c.id WHERE s.id=$id")->fetch_assoc();
if(!$sale){echo "Invoice not found.";exit();}
$items=$conn->query("SELECT * FROM sale_items WHERE sale_id=$id");
?>
<!DOCTYPE html><html lang="en"><head>
<meta charset="UTF-8"><title>Invoice <?=$sale['invoice_no']?> — Uttara Pet Shop</title>
<link rel="stylesheet" href="../assets/css/style.css">
<style>
body{background:var(--cream)}
.inv-wrap{max-width:640px;margin:30px auto;background:#fff;border:1px solid var(--border);border-radius:16px;padding:40px;box-shadow:var(--shadow-lg)}
.inv-top{display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:28px;padding-bottom:20px;border-bottom:2px solid var(--border)}
.inv-shop-name{font-family:'Playfair Display',serif;font-size:22px;color:var(--brown-deep)}
.inv-shop-sub{font-size:11px;color:var(--text-muted);letter-spacing:1px;text-transform:uppercase}
.inv-no{font-family:'DM Mono';color:var(--forest-mid);font-size:15px;font-weight:500}
.inv-meta{display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:24px}
.inv-meta-item label{font-size:11px;color:var(--text-muted);text-transform:uppercase;letter-spacing:.5px;display:block;margin-bottom:3px}
.inv-meta-item span{font-size:13px;color:var(--text-dark)}
.inv-table{width:100%;border-collapse:collapse;margin:20px 0}
.inv-table th{padding:9px 12px;font-size:11px;text-transform:uppercase;color:var(--text-light);border-bottom:2px solid var(--border);text-align:left;background:var(--cream)}
.inv-table td{padding:11px 12px;font-size:13px;border-bottom:1px solid var(--cream-dark);color:var(--text-mid)}
.inv-totals{margin-top:8px;border-top:2px solid var(--border);padding-top:10px}
.inv-row{display:flex;justify-content:space-between;padding:6px 0;font-size:13px;color:var(--text-mid)}
.inv-grand{font-family:'DM Mono';font-size:24px;font-weight:500;color:var(--forest)}
.inv-footer{text-align:center;margin-top:24px;padding-top:18px;border-top:1px solid var(--border);font-size:12px;color:var(--text-muted)}
/* Print button bar — prominent, especially for new sales */
.action-bar{max-width:640px;margin:0 auto 20px;display:flex;gap:12px;flex-wrap:wrap}
.print-btn-big{background:var(--forest);color:#fff;border:none;padding:14px 28px;border-radius:10px;font-size:15px;font-weight:600;font-family:'DM Sans';cursor:pointer;display:flex;align-items:center;gap:8px;box-shadow:0 4px 16px rgba(45,80,22,0.3);transition:all .2s}
.print-btn-big:hover{background:var(--forest-mid);transform:translateY(-1px);box-shadow:0 6px 20px rgba(45,80,22,0.4)}
/* New sale success banner */
.success-banner{max-width:640px;margin:0 auto 16px;background:var(--forest-glow);border:1px solid var(--forest-mid);border-radius:10px;padding:14px 20px;display:flex;align-items:center;gap:12px;font-size:14px;color:var(--forest)}
@media print{.no-print{display:none!important}body{background:white}.inv-wrap{box-shadow:none;border:1px solid #ddd;margin:0;border-radius:0}}
</style>
</head><body>

<?php if($new): ?>
<div class="success-banner no-print">
    <span style="font-size:24px">✅</span>
    <div><b>Sale completed successfully!</b> Invoice <?=$sale['invoice_no']?> has been saved. Print or save the receipt below.</div>
</div>
<?php endif; ?>

<!-- ACTION BAR — always visible, prominent -->
<div class="action-bar no-print">
    <button onclick="window.print()" class="print-btn-big">🖨️ Print Receipt</button>
    <a href="new_sale.php" class="btn btn-outline" style="padding:14px 20px">+ New Sale</a>
    <a href="sales.php" class="btn btn-outline" style="padding:14px 20px">📋 Sales List</a>
    <button onclick="savePDF()" class="btn btn-outline" style="padding:14px 20px">💾 Save as PDF</button>
</div>

<div class="inv-wrap" id="invoicePrint">
    <div class="inv-top">
        <div>
            <div style="font-size:36px;margin-bottom:6px">🐾</div>
            <div class="inv-shop-name">Uttara Pet Shop</div>
            <div class="inv-shop-sub">Pet Shop & Aquarium Gallery</div>
        </div>
        <div style="text-align:right">
            <div class="inv-no"><?=$sale['invoice_no']?></div>
            <div style="font-size:12px;color:var(--text-muted);margin-top:6px"><?=date('d M Y, h:i A',strtotime($sale['sale_date']))?></div>
        </div>
    </div>

    <div class="inv-meta">
        <div class="inv-meta-item"><label>Customer</label><span><?=htmlspecialchars($sale['customer_name']??'Walk-in Customer')?></span></div>
        <div class="inv-meta-item"><label>Phone</label><span><?=htmlspecialchars($sale['customer_phone']??'—')?></span></div>
        <div class="inv-meta-item"><label>Served by</label><span><?=htmlspecialchars($sale['cashier'])?></span></div>
        <div class="inv-meta-item"><label>Payment</label>
            <span><?=paymentLabel($sale['payment_method'])?>
            <?php if($sale['payment_ref']): ?>
                <br><small style="color:var(--text-muted);font-size:11px">Ref: <?=htmlspecialchars($sale['payment_ref'])?></small>
            <?php endif; ?></span>
        </div>
    </div>

    <table class="inv-table">
        <thead><tr><th>#</th><th>Item</th><th>Type</th><th>Qty</th><th>Unit Price</th><th>Total</th></tr></thead>
        <tbody>
        <?php $i=1;while($r=$items->fetch_assoc()): ?>
        <tr>
            <td><?=$i++?></td>
            <td><b style="color:var(--brown-deep)"><?=htmlspecialchars($r['item_name'])?></b></td>
            <td><span class="badge badge-sand"><?=ucfirst($r['item_type'])?></span></td>
            <td><?=$r['quantity']?></td>
            <td><?=money($r['unit_price'])?></td>
            <td style="font-weight:600;color:var(--amber)"><?=money($r['total_price'])?></td>
        </tr>
        <?php endwhile; ?>
        </tbody>
    </table>

    <div class="inv-totals">
        <div class="inv-row"><span>Subtotal</span><span><?=money($sale['subtotal'])?></span></div>
        <?php if($sale['discount']>0): ?>
        <div class="inv-row" style="color:var(--coral)"><span>Discount</span><span>– <?=money($sale['discount'])?></span></div>
        <?php endif; ?>
        <div class="inv-row" style="font-size:16px;font-weight:600;color:var(--brown-deep);margin-top:6px;padding-top:8px;border-top:1px solid var(--border)">
            <span>Grand Total</span><span class="inv-grand"><?=money($sale['total'])?></span>
        </div>
    </div>

    <?php if($sale['notes']): ?>
    <div style="margin-top:14px;padding:12px;background:var(--cream);border-radius:8px;font-size:12px;color:var(--text-mid)">📝 <?=htmlspecialchars($sale['notes'])?></div>
    <?php endif; ?>

    <div class="inv-footer">
        🐾 Thank you for shopping at Uttara Pet Shop! 🐾<br>
        We hope your pets bring you joy every day.
    </div>
</div>

<script>
function savePDF() {
    window.print(); // Browser "Save as PDF" option in print dialog
}
</script>
</body></html>
