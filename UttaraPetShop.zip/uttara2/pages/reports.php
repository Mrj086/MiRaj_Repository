<?php
require_once '../includes/config.php'; require_once '../includes/layout.php'; requireLogin(); if(!isAdmin()){header("Location: dashboard.php");exit();}
$monthly=[];for($m=1;$m<=12;$m++){$r=$conn->query("SELECT COALESCE(SUM(total),0) t FROM sales WHERE MONTH(sale_date)=$m AND YEAR(sale_date)=YEAR(NOW())")->fetch_assoc();$monthly[]=(float)$r['t'];}
$topItems=$conn->query("SELECT item_name,item_type,SUM(quantity) qty_sold,SUM(total_price) revenue FROM sale_items GROUP BY item_name,item_type ORDER BY revenue DESC LIMIT 8");
$payments=$conn->query("SELECT payment_method,COUNT(*) cnt,SUM(total) total FROM sales GROUP BY payment_method ORDER BY total DESC");
$payData=[];while($r=$payments->fetch_assoc())$payData[]=$r;
$poStats=$conn->query("SELECT status,COUNT(*) cnt,COALESCE(SUM(total_amount),0) val FROM purchase_orders GROUP BY status");
$poData=[];while($r=$poStats->fetch_assoc())$poData[]=$r;
$supplierSpend=$conn->query("SELECT s.name,COALESCE(SUM(po.total_amount),0) total FROM suppliers s LEFT JOIN purchase_orders po ON po.supplier_id=s.id GROUP BY s.id ORDER BY total DESC LIMIT 5");
?>
<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Reports — Uttara Pet Shop</title><link rel="stylesheet" href="../assets/css/style.css"><script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.0/chart.umd.min.js"></script></head><body>
<?php renderSidebar('reports'); ?>
<div class="main"><?php pageHeader('📊 Reports','Business analytics & insights'); ?>
<div style="display:grid;grid-template-columns:2fr 1fr;gap:20px;margin-bottom:20px">
<div class="card"><div class="card-title">📈 Monthly Sales — <?=date('Y')?></div><canvas id="mc" height="110"></canvas></div>
<div class="card"><div class="card-title">💳 Payment Methods</div>
<?php foreach($payData as $p): ?>
<div style="display:flex;justify-content:space-between;align-items:center;padding:8px 0;border-bottom:1px solid var(--border);font-size:13px">
<span><?=paymentLabel($p['payment_method'])?></span>
<div style="text-align:right"><b style="color:var(--amber)"><?=money($p['total'])?></b><div style="font-size:11px;color:var(--text-muted)"><?=$p['cnt']?> sales</div></div></div>
<?php endforeach; ?></div></div>
<div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-bottom:20px">
<div class="card"><div class="card-title">🏆 Top Selling Items</div><div class="table-wrap"><table>
<thead><tr><th>Item</th><th>Type</th><th>Qty</th><th>Revenue</th></tr></thead><tbody>
<?php while($r=$topItems->fetch_assoc()): ?><tr><td><?=htmlspecialchars($r['item_name'])?></td><td><span class="badge badge-green"><?=ucfirst($r['item_type'])?></span></td><td><?=$r['qty_sold']?></td><td style="color:var(--amber);font-weight:600"><?=money($r['revenue'])?></td></tr><?php endwhile; ?>
<?php if(!isset($r)): ?><tr><td colspan="4" style="text-align:center;padding:20px;color:var(--text-muted)">No sales yet</td></tr><?php endif; ?>
</tbody></table></div></div>
<div class="card"><div class="card-title">🚚 Supplier Spending</div><div class="table-wrap"><table>
<thead><tr><th>Supplier</th><th>Total Ordered</th></tr></thead><tbody>
<?php while($r=$supplierSpend->fetch_assoc()): ?><tr><td><b><?=htmlspecialchars($r['name'])?></b></td><td style="color:var(--amber);font-weight:600"><?=money($r['total'])?></td></tr><?php endwhile; ?>
</tbody></table></div>
<div style="margin-top:14px"><div class="card-title" style="margin-top:10px">Purchase Order Status</div>
<?php foreach($poData as $p): ?><div style="display:flex;justify-content:space-between;padding:7px 0;border-bottom:1px solid var(--border);font-size:13px"><span><?=ucfirst(str_replace('_',' ',$p['status']))?></span><span><?=$p['cnt']?> orders · <b style="color:var(--amber)"><?=money($p['val'])?></b></span></div><?php endforeach; ?></div>
</div></div></div>
<script>
const months=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
new Chart(document.getElementById('mc'),{type:'bar',data:{labels:months,datasets:[{data:<?=json_encode($monthly)?>,backgroundColor:'rgba(45,80,22,0.15)',borderColor:'#3d6b20',borderWidth:2,borderRadius:8}]},options:{responsive:true,plugins:{legend:{display:false}},scales:{x:{grid:{color:'rgba(196,168,130,0.3)'},ticks:{color:'#a07850'}},y:{grid:{color:'rgba(196,168,130,0.3)'},ticks:{color:'#a07850'}}}}});
function toggleSidebar(){document.getElementById('sidebar').classList.toggle('open');}
</script></body></html>
