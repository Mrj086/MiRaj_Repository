<?php
require_once '../includes/config.php';
require_once '../includes/layout.php';
requireLogin();

$msg='';$msgType='success';

if($_SERVER['REQUEST_METHOD']==='POST') {
    $current = $_POST['current_password']??'';
    $new     = clean($_POST['new_password']??'');
    $confirm = clean($_POST['confirm_password']??'');

    $uid  = $_SESSION['user_id'];
    $user = $conn->query("SELECT password FROM users WHERE id=$uid")->fetch_assoc();

    if(md5($current) !== $user['password']) {
        $msg="Current password is incorrect!"; $msgType='danger';
    } elseif(strlen($new)<6) {
        $msg="New password must be at least 6 characters!"; $msgType='danger';
    } elseif($new !== $confirm) {
        $msg="New passwords do not match!"; $msgType='danger';
    } else {
        $hashed=md5($new);
        $conn->query("UPDATE users SET password='$hashed' WHERE id=$uid");
        $msg="Password changed successfully!";
    }
}
?>
<!DOCTYPE html><html lang="en"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Change Password — Uttara Pet Shop</title>
<link rel="stylesheet" href="../assets/css/style.css">
</head><body>
<?php renderSidebar(''); ?>
<div class="main">
<?php pageHeader('🔑 Change Password','Update your login password',false); ?>

<div style="max-width:480px">
    <?php if($msg): ?><div class="alert alert-<?=$msgType?>"><?=$msg?></div><?php endif; ?>
    <div class="card">
        <div class="card-title">Update Your Password</div>
        <form method="POST">
            <div class="form-group">
                <label class="form-label">Current Password *</label>
                <input type="password" name="current_password" class="form-control" required placeholder="Your current password">
            </div>
            <div class="form-group">
                <label class="form-label">New Password *</label>
                <input type="password" name="new_password" class="form-control" required placeholder="At least 6 characters" id="np">
            </div>
            <div class="form-group">
                <label class="form-label">Confirm New Password *</label>
                <input type="password" name="confirm_password" class="form-control" required placeholder="Repeat new password" oninput="checkMatch(this)">
                <div id="matchMsg" style="font-size:12px;margin-top:4px"></div>
            </div>
            <button type="submit" class="btn btn-primary" style="width:100%;justify-content:center;padding:12px">Update Password</button>
        </form>
    </div>

    <div class="card" style="margin-top:16px">
        <div class="card-title">Password Tips</div>
        <ul style="font-size:13px;color:var(--text-mid);line-height:2;padding-left:18px">
            <li>Use at least 6 characters</li>
            <li>Mix letters and numbers for security</li>
            <li>Don't share your password with others</li>
            <li>Change your password regularly</li>
        </ul>
    </div>
</div>
</div>
<script>
function checkMatch(el){
    const np=document.getElementById('np').value;
    const msg=document.getElementById('matchMsg');
    if(!el.value)return;
    if(el.value===np){msg.textContent='✅ Passwords match';msg.style.color='var(--forest)';}
    else{msg.textContent='❌ Passwords do not match';msg.style.color='var(--coral)';}
}
function toggleSidebar(){document.getElementById('sidebar').classList.toggle('open');}
</script>
</body></html>
