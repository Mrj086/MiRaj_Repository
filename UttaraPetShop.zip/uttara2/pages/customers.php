<?php
require_once '../includes/config.php'; require_once '../includes/layout.php'; requireLogin();
$msg='';$msgType='success';
if($_SERVER['REQUEST_METHOD']==='POST'){
    $action=$_POST['action']??'';
    if($action==='add'||$action==='edit'){
        $id=(int)($_POST['id']??0);$name=clean($_POST['name']);$phone=clean($_POST['phone']);$email=clean($_POST['email']);$addr=clean($_POST['address']);
        if($action==='add'){$conn->query("INSERT INTO customers (name,phone,email,address) VALUES ('$name','$phone','$email','$addr')");$msg="Customer added!";}
        else{$conn->query("UPDATE customers SET name='$name',phone='$phone',email='$email',address='$addr' WHERE id=$id");$msg="Updated!";}
    }
    if($action==='delete'&&isAdmin()&&(int)$_POST['id']!==1){$conn->query("DELETE FROM customers WHERE id=".(int)$_POST['id']);$msg="Removed.";$msgType='warning';}
}
$search=clean($_GET['search']??'');$where=$search?"WHERE c.name LIKE '%$search%' OR c.phone LIKE '%$search%'":'';
$customers=$conn->query("SELECT c.*,(SELECT COUNT(*) FROM sales WHERE customer_id=c.id) orders,(SELECT COALESCE(SUM(total),0) FROM sales WHERE customer_id=c.id) spent FROM customers c $where ORDER BY c.name");
?>
<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Customers — Uttara Pet Shop</title><link rel="stylesheet" href="../assets/css/style.css"></head><body>
<?php renderSidebar('customers'); ?>
<div class="main"><?php pageHeader('👥 Customers','Manage customer base'); ?>
<?php if($msg): ?><div class="alert alert-<?=$msgType?>"><?=$msg?></div><?php endif; ?>
<div class="section-bar"><h2>All Customers</h2><button class="btn btn-primary" onclick="openModal('addModal')">+ Add Customer</button></div>
<div class="search-bar"><form method="GET" style="display:flex;gap:10px;flex:1"><input type="text" name="search" class="form-control" placeholder="Search by name or phone..." value="<?=htmlspecialchars($search)?>"><button type="submit" class="btn btn-outline">Search</button><?php if($search): ?><a href="customers.php" class="btn btn-outline">✕</a><?php endif; ?></form></div>
<div class="card"><div class="table-wrap"><table>
<thead><tr><th>#</th><th>Name</th><th>Phone</th><th>Email</th><th>Orders</th><th>Total Spent</th><th>Since</th><th>Actions</th></tr></thead>
<tbody><?php $i=1;while($r=$customers->fetch_assoc()): ?><tr>
<td><?=$i++?></td><td><b style="color:var(--brown-deep)"><?=htmlspecialchars($r['name'])?></b></td>
<td><?=htmlspecialchars($r['phone']??'—')?></td><td style="color:var(--text-muted)"><?=htmlspecialchars($r['email']??'—')?></td>
<td><span class="badge badge-green"><?=$r['orders']?></span></td>
<td style="color:var(--amber);font-weight:600"><?=money($r['spent'])?></td>
<td style="color:var(--text-muted)"><?=date('d M Y',strtotime($r['created_at']))?></td>
<td><button class="btn btn-outline btn-sm" onclick='editC(<?=json_encode($r)?>)'>Edit</button>
<?php if(isAdmin()&&$r['id']!=1): ?><form method="POST" style="display:inline" onsubmit="return confirm('Remove?')"><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?=$r['id']?>"><button type="submit" class="btn btn-danger btn-sm">Del</button></form><?php endif; ?></td>
</tr><?php endwhile; ?></tbody></table></div></div>
<div class="modal-overlay" id="addModal"><div class="modal"><div class="modal-header"><span class="modal-title">Add Customer</span><button class="modal-close" onclick="closeModal('addModal')">✕</button></div>
<form method="POST"><input type="hidden" name="action" value="add">
<div class="form-group"><label class="form-label">Full Name *</label><input type="text" name="name" class="form-control" required></div>
<div class="form-grid"><div class="form-group"><label class="form-label">Phone</label><input type="text" name="phone" class="form-control"></div><div class="form-group"><label class="form-label">Email</label><input type="email" name="email" class="form-control"></div></div>
<div class="form-group"><label class="form-label">Address</label><textarea name="address" class="form-control" rows="2"></textarea></div>
<button type="submit" class="btn btn-primary" style="width:100%;justify-content:center">Add Customer</button></form></div></div>
<div class="modal-overlay" id="editModal"><div class="modal"><div class="modal-header"><span class="modal-title">Edit Customer</span><button class="modal-close" onclick="closeModal('editModal')">✕</button></div>
<form method="POST"><input type="hidden" name="action" value="edit"><input type="hidden" name="id" id="e_id">
<div class="form-group"><label class="form-label">Full Name *</label><input type="text" name="name" id="e_name" class="form-control" required></div>
<div class="form-grid"><div class="form-group"><label class="form-label">Phone</label><input type="text" name="phone" id="e_ph" class="form-control"></div><div class="form-group"><label class="form-label">Email</label><input type="email" name="email" id="e_em" class="form-control"></div></div>
<div class="form-group"><label class="form-label">Address</label><textarea name="address" id="e_addr" class="form-control" rows="2"></textarea></div>
<button type="submit" class="btn btn-amber" style="width:100%;justify-content:center">Update</button></form></div></div>
<script>
function openModal(id){document.getElementById(id).classList.add('open');}function closeModal(id){document.getElementById(id).classList.remove('open');}
function editC(d){document.getElementById('e_id').value=d.id;document.getElementById('e_name').value=d.name;document.getElementById('e_ph').value=d.phone||'';document.getElementById('e_em').value=d.email||'';document.getElementById('e_addr').value=d.address||'';openModal('editModal');}
function toggleSidebar(){document.getElementById('sidebar').classList.toggle('open');}
</script></div></body></html>
