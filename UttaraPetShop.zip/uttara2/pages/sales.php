<?php
require_once '../includes/config.php'; require_once '../includes/layout.php'; requireLogin();
$from=$_GET['from']??date('Y-m-01');$to=$_GET['to']??date('Y-m-d');$search=clean($_GET['search']??'');
$where="WHERE DATE(s.sale_date) BETWEEN '$from' AND '$to'";
if($search) $where.=" AND (s.invoice_no LIKE '%$search%' OR c.name LIKE '%$search%')";
$sales=$conn->query("SELECT s.*,COALESCE(c.name,'Walk-in') customer,u.full_name cashier FROM sales s LEFT JOIN customers c ON s.customer_id=c.id LEFT JOIN users u ON s.user_id=u.id $where ORDER BY s.sale_date DESC");
$sum=$conn->query("SELECT COALESCE(SUM(total),0) total,COUNT(*) cnt,COALESCE(SUM(discount),0) disc FROM sales s LEFT JOIN customers c ON s.customer_id=c.id $where")->fetch_assoc();
?>
<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Sales — Uttara Pet Shop</title><link rel="stylesheet" href="../assets/css/style.css"></head><body>
<?php renderSidebar('sales'); ?>
<div class="main"><?php pageHeader('🧾 Sales History','All transactions'); ?>
<div class="card" style="margin-bottom:16px">
<form method="GET" style="display:flex;gap:12px;flex-wrap:wrap;align-items:flex-end">
<div class="form-group" style="margin:0;flex:0 0 140px"><label class="form-label">From</label><input type="date" name="from" class="form-control" value="<?=$from?>"></div>
<div class="form-group" style="margin:0;flex:0 0 140px"><label class="form-label">To</label><input type="date" name="to" class="form-control" value="<?=$to?>"></div>
<div class="form-group" style="margin:0;flex:1;min-width:200px"><label class="form-label">Search</label><input type="text" name="search" class="form-control" placeholder="Invoice # or customer..." value="<?=htmlspecialchars($search)?>"></div>
<button type="submit" class="btn btn-primary">Filter</button><a href="sales.php" class="btn btn-outline">Clear</a>
</form></div>
<div style="display:flex;gap:14px;margin-bottom:16px;flex-wrap:wrap">
<div class="stat-card green" style="flex:1;padding:14px;min-width:140px"><div class="s-label">Revenue</div><div style="font-family:'DM Mono';font-size:20px;font-weight:500;color:var(--forest-mid)"><?=money($sum['total'])?></div></div>
<div class="stat-card amber" style="flex:1;padding:14px;min-width:140px"><div class="s-label">Transactions</div><div style="font-family:'DM Mono';font-size:20px;font-weight:500;color:var(--amber)"><?=$sum['cnt']?></div></div>
<div class="stat-card coral" style="flex:1;padding:14px;min-width:140px"><div class="s-label">Discounts Given</div><div style="font-family:'DM Mono';font-size:20px;font-weight:500;color:var(--coral)"><?=money($sum['disc'])?></div></div>
</div>
<div class="card"><div class="table-wrap"><table>
<thead><tr><th>Invoice</th><th>Customer</th><th>Cashier</th><th>Total</th><th>Payment</th><th>Ref</th><th>Date</th><th></th></tr></thead>
<tbody><?php while($r=$sales->fetch_assoc()): ?><tr>
<td><span style="font-family:'DM Mono';color:var(--forest-mid)"><?=$r['invoice_no']?></span></td>
<td><?=htmlspecialchars($r['customer'])?></td>
<td style="color:var(--text-muted)"><?=htmlspecialchars($r['cashier'])?></td>
<td><b style="color:var(--amber)"><?=money($r['total'])?><?=$r['discount']>0?' <small style="color:var(--coral)">(-'.money($r['discount']).')</small>':''?></b></td>
<td><span class="badge badge-green" style="font-size:10px"><?=paymentLabel($r['payment_method'])?></span></td>
<td style="color:var(--text-muted);font-size:11px"><?=htmlspecialchars($r['payment_ref']??'—')?></td>
<td style="color:var(--text-muted)"><?=date('d M Y, h:i A',strtotime($r['sale_date']))?></td>
<td><a href="invoice.php?id=<?=$r['id']?>" class="btn btn-outline btn-sm">🧾 View</a></td>
</tr><?php endwhile; ?></tbody></table></div></div>
</div>
<script>function toggleSidebar(){document.getElementById('sidebar').classList.toggle('open');}</script>
</body></html>
