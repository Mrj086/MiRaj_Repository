<?php
require_once '../includes/config.php';
require_once '../includes/layout.php';
requireLogin(); if(!isAdmin()){header("Location: dashboard.php");exit();}

$msg='';$msgType='success';

if($_SERVER['REQUEST_METHOD']==='POST') {
    $action=$_POST['action']??'';

    if($action==='add') {
        $fname   =clean($_POST['full_name']);
        $uname   =clean($_POST['username']);
        $role    =clean($_POST['role']);
        $pass    =clean($_POST['password']);
        $confirm =clean($_POST['confirm_password']);
        if($pass!==$confirm){ $msg="Passwords do not match!";$msgType='danger'; }
        elseif(strlen($pass)<6){ $msg="Password must be at least 6 characters!";$msgType='danger'; }
        else {
            $hashed=md5($pass);
            $check=$conn->query("SELECT id FROM users WHERE username='$uname'")->num_rows;
            if($check){ $msg="Username '$uname' already exists!";$msgType='danger'; }
            else {
                $conn->query("INSERT INTO users (full_name,username,password,role) VALUES ('$fname','$uname','$hashed','$role')");
                $msg="Staff member '$fname' added!";
            }
        }
    }

    if($action==='toggle_active') {
        $id=(int)$_POST['id'];
        $conn->query("UPDATE users SET is_active=1-is_active WHERE id=$id AND id!=1"); // protect admin id=1
        $msg="Status updated.";
    }

    if($action==='reset_password') {
        $id      =(int)$_POST['id'];
        $newpass =clean($_POST['new_password']);
        $confirm =clean($_POST['confirm_password']);
        if($newpass!==$confirm){ $msg="Passwords do not match!";$msgType='danger'; }
        elseif(strlen($newpass)<6){ $msg="Password must be at least 6 characters!";$msgType='danger'; }
        else {
            $hashed=md5($newpass);
            $conn->query("UPDATE users SET password='$hashed' WHERE id=$id");
            $msg="Password updated successfully!";
        }
    }

    if($action==='delete' && (int)$_POST['id']!==1) {
        $conn->query("DELETE FROM users WHERE id=".(int)$_POST['id']);
        $msg="Staff removed.";$msgType='warning';
    }
}

$staff=$conn->query("SELECT * FROM users ORDER BY role,full_name");
?>
<!DOCTYPE html><html lang="en"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Staff — Uttara Pet Shop</title>
<link rel="stylesheet" href="../assets/css/style.css">
</head><body>
<?php renderSidebar('staff'); ?>
<div class="main">
<?php pageHeader('👤 Staff Management','Manage cashiers and admin accounts'); ?>
<?php if($msg): ?><div class="alert alert-<?=$msgType?>"><?=$msg?></div><?php endif; ?>

<div class="section-bar">
    <h2>All Staff</h2>
    <button class="btn btn-primary" onclick="openModal('addStaffModal')">+ Add Staff</button>
</div>

<div class="card">
<div class="table-wrap"><table>
<thead><tr><th>#</th><th>Name</th><th>Username</th><th>Role</th><th>Status</th><th>Joined</th><th>Actions</th></tr></thead>
<tbody>
<?php $i=1; while($r=$staff->fetch_assoc()): ?>
<tr>
    <td><?=$i++?></td>
    <td><b style="color:var(--brown-deep)"><?=htmlspecialchars($r['full_name'])?></b></td>
    <td><span style="font-family:'DM Mono';font-size:13px"><?=htmlspecialchars($r['username'])?></span></td>
    <td><span class="badge <?=$r['role']==='admin'?'badge-amber':'badge-green'?>"><?=ucfirst($r['role'])?></span></td>
    <td><span class="badge <?=$r['is_active']?'badge-green':'badge-coral'?>"><?=$r['is_active']?'Active':'Inactive'?></span></td>
    <td style="color:var(--text-muted)"><?=date('d M Y',strtotime($r['created_at']))?></td>
    <td>
        <button class="btn btn-outline btn-sm" onclick='openResetModal(<?=$r['id']?>, "<?=htmlspecialchars($r['full_name'])?>" )'>🔑 Password</button>
        <?php if($r['id']!==$_SESSION['user_id']): ?>
        <form method="POST" style="display:inline">
            <input type="hidden" name="action" value="toggle_active">
            <input type="hidden" name="id" value="<?=$r['id']?>">
            <button type="submit" class="btn btn-outline btn-sm"><?=$r['is_active']?'Deactivate':'Activate'?></button>
        </form>
        <?php if($r['id']!==1): ?>
        <form method="POST" style="display:inline" onsubmit="return confirm('Remove this staff member?')">
            <input type="hidden" name="action" value="delete">
            <input type="hidden" name="id" value="<?=$r['id']?>">
            <button type="submit" class="btn btn-danger btn-sm">Delete</button>
        </form>
        <?php endif; ?>
        <?php endif; ?>
    </td>
</tr>
<?php endwhile; ?>
</tbody>
</table></div>
</div>

<!-- Add Staff Modal -->
<div class="modal-overlay" id="addStaffModal">
<div class="modal">
    <div class="modal-header"><span class="modal-title">👤 Add Staff Member</span><button class="modal-close" onclick="closeModal('addStaffModal')">✕</button></div>
    <form method="POST">
        <input type="hidden" name="action" value="add">
        <div class="form-group"><label class="form-label">Full Name *</label><input type="text" name="full_name" class="form-control" required placeholder="e.g. Rahim Ahmed"></div>
        <div class="form-grid">
            <div class="form-group"><label class="form-label">Username *</label><input type="text" name="username" class="form-control" required placeholder="e.g. cashier3"></div>
            <div class="form-group"><label class="form-label">Role *</label>
                <select name="role" class="form-control">
                    <option value="cashier">Cashier</option>
                    <option value="admin">Admin</option>
                </select></div>
        </div>
        <div class="form-grid">
            <div class="form-group"><label class="form-label">Password *</label><input type="password" name="password" class="form-control" required placeholder="Min 6 characters"></div>
            <div class="form-group"><label class="form-label">Confirm Password *</label><input type="password" name="confirm_password" class="form-control" required></div>
        </div>
        <button type="submit" class="btn btn-primary" style="width:100%;justify-content:center">Add Staff Member</button>
    </form>
</div>
</div>

<!-- Reset Password Modal -->
<div class="modal-overlay" id="resetModal">
<div class="modal">
    <div class="modal-header"><span class="modal-title">🔑 Reset Password</span><button class="modal-close" onclick="closeModal('resetModal')">✕</button></div>
    <p style="font-size:13px;color:var(--text-mid);margin-bottom:18px">Resetting password for: <b id="resetName"></b></p>
    <form method="POST">
        <input type="hidden" name="action" value="reset_password">
        <input type="hidden" name="id" id="resetId">
        <div class="form-group"><label class="form-label">New Password *</label><input type="password" name="new_password" class="form-control" required placeholder="Min 6 characters"></div>
        <div class="form-group"><label class="form-label">Confirm New Password *</label><input type="password" name="confirm_password" class="form-control" required></div>
        <button type="submit" class="btn btn-amber" style="width:100%;justify-content:center">Update Password</button>
    </form>
</div>
</div>

<script>
function openModal(id){document.getElementById(id).classList.add('open');}
function closeModal(id){document.getElementById(id).classList.remove('open');}
function openResetModal(id,name){document.getElementById('resetId').value=id;document.getElementById('resetName').textContent=name;openModal('resetModal');}
function toggleSidebar(){document.getElementById('sidebar').classList.toggle('open');}
</script>
</body></html>
