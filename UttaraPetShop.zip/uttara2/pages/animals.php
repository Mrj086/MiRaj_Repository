<?php
require_once '../includes/config.php'; require_once '../includes/layout.php'; requireLogin();
$msg='';$msgType='success';
if($_SERVER['REQUEST_METHOD']==='POST'){
    $action=$_POST['action']??'';
    if($action==='add'||$action==='edit'){
        $id=(int)($_POST['id']??0);$cat=(int)$_POST['category_id'];$sup=(int)$_POST['supplier_id'];
        $name=clean($_POST['name']);$spec=clean($_POST['species']);$desc=clean($_POST['description']);
        $buy=(float)$_POST['buying_price'];$sell=(float)$_POST['selling_price'];
        $qty=(int)$_POST['stock_quantity'];$alert=(int)$_POST['low_stock_alert'];$care=clean($_POST['care_level']);
        if($action==='add'){$conn->query("INSERT INTO animals (category_id,supplier_id,name,species,description,buying_price,selling_price,stock_quantity,low_stock_alert,care_level) VALUES ($cat,$sup,'$name','$spec','$desc',$buy,$sell,$qty,$alert,'$care')");$msg="Animal '$name' added!";}
        else{$conn->query("UPDATE animals SET category_id=$cat,supplier_id=$sup,name='$name',species='$spec',description='$desc',buying_price=$buy,selling_price=$sell,stock_quantity=$qty,low_stock_alert=$alert,care_level='$care' WHERE id=$id");$msg="Updated!";}
    }
    if($action==='delete'&&isAdmin()){$conn->query("DELETE FROM animals WHERE id=".(int)$_POST['id']);$msg="Deleted.";$msgType='warning';}
}
$search=clean($_GET['search']??'');$where=$search?"WHERE a.name LIKE '%$search%' OR a.species LIKE '%$search%'":'';
$animals=$conn->query("SELECT a.*,c.name cat_name FROM animals a LEFT JOIN categories c ON a.category_id=c.id $where ORDER BY a.name");
$categories=$conn->query("SELECT * FROM categories WHERE type='animal' ORDER BY name");
$suppliers=$conn->query("SELECT * FROM suppliers ORDER BY name");
?>
<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Animals — Uttara Pet Shop</title><link rel="stylesheet" href="../assets/css/style.css"></head><body>
<?php renderSidebar('animals'); ?>
<div class="main"><?php pageHeader('🐾 Animals','Manage your living inventory'); ?>
<?php if($msg): ?><div class="alert alert-<?=$msgType?>"><?=$msg?></div><?php endif; ?>
<div class="section-bar"><h2>All Animals</h2><button class="btn btn-primary" onclick="openModal('addModal')">+ Add Animal</button></div>
<div class="search-bar"><form method="GET" style="display:flex;gap:10px;flex:1"><input type="text" name="search" class="form-control" placeholder="Search by name or species..." value="<?=htmlspecialchars($search)?>"><button type="submit" class="btn btn-outline">Search</button><?php if($search): ?><a href="animals.php" class="btn btn-outline">✕</a><?php endif; ?></form></div>
<div class="card"><div class="table-wrap"><table>
<thead><tr><th>#</th><th>Name</th><th>Species</th><th>Category</th><th>Care</th><th>Buy</th><th>Sell</th><th>Stock</th><th>Actions</th></tr></thead>
<tbody><?php $i=1;while($r=$animals->fetch_assoc()): ?>
<tr class="<?=$r['stock_quantity']<=$r['low_stock_alert']?'low-stock-row':''?>">
<td><?=$i++?></td><td><b style="color:var(--brown-deep)"><?=htmlspecialchars($r['name'])?></b></td>
<td style="font-style:italic;color:var(--text-muted)"><?=htmlspecialchars($r['species']??'')?></td>
<td><span class="badge badge-green"><?=htmlspecialchars($r['cat_name']??'—')?></span></td>
<td><?php $cb=['easy'=>'badge-green','moderate'=>'badge-amber','expert'=>'badge-coral'][$r['care_level']]??'badge-sand';?><span class="badge <?=$cb?>"><?=ucfirst($r['care_level'])?></span></td>
<td><?=money($r['buying_price'])?></td><td style="color:var(--amber);font-weight:600"><?=money($r['selling_price'])?></td>
<td><?=$r['stock_quantity']<=$r['low_stock_alert']?'<span class="badge badge-coral">'.$r['stock_quantity'].' ⚠</span>':'<span class="badge badge-green">'.$r['stock_quantity'].'</span>'?></td>
<td><button class="btn btn-outline btn-sm" onclick='editAnimal(<?=json_encode($r)?>)'>Edit</button>
<?php if(isAdmin()): ?><form method="POST" style="display:inline" onsubmit="return confirm('Delete?')"><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?=$r['id']?>"><button type="submit" class="btn btn-danger btn-sm">Del</button></form><?php endif; ?></td>
</tr><?php endwhile; ?></tbody></table></div></div>
<div class="modal-overlay" id="addModal"><div class="modal"><div class="modal-header"><span class="modal-title">Add Animal</span><button class="modal-close" onclick="closeModal('addModal')">✕</button></div>
<form method="POST"><input type="hidden" name="action" value="add">
<div class="form-grid"><div class="form-group"><label class="form-label">Name *</label><input type="text" name="name" class="form-control" required></div><div class="form-group"><label class="form-label">Species</label><input type="text" name="species" class="form-control"></div></div>
<div class="form-grid"><div class="form-group"><label class="form-label">Category</label><select name="category_id" class="form-control"><option value="0">--</option><?php $categories->data_seek(0);while($c=$categories->fetch_assoc()): ?><option value="<?=$c['id']?>"><?=htmlspecialchars($c['name'])?></option><?php endwhile; ?></select></div>
<div class="form-group"><label class="form-label">Supplier</label><select name="supplier_id" class="form-control"><option value="0">--</option><?php $suppliers->data_seek(0);while($s=$suppliers->fetch_assoc()): ?><option value="<?=$s['id']?>"><?=htmlspecialchars($s['name'])?></option><?php endwhile; ?></select></div></div>
<div class="form-grid-3"><div class="form-group"><label class="form-label">Buy Price *</label><input type="number" name="buying_price" class="form-control" step="0.01" required></div><div class="form-group"><label class="form-label">Sell Price *</label><input type="number" name="selling_price" class="form-control" step="0.01" required></div><div class="form-group"><label class="form-label">Care Level</label><select name="care_level" class="form-control"><option value="easy">Easy</option><option value="moderate">Moderate</option><option value="expert">Expert</option></select></div></div>
<div class="form-grid"><div class="form-group"><label class="form-label">Stock *</label><input type="number" name="stock_quantity" class="form-control" value="0" required></div><div class="form-group"><label class="form-label">Alert At</label><input type="number" name="low_stock_alert" class="form-control" value="2"></div></div>
<div class="form-group"><label class="form-label">Description</label><textarea name="description" class="form-control" rows="2"></textarea></div>
<button type="submit" class="btn btn-primary" style="width:100%;justify-content:center">Add Animal</button></form></div></div>
<div class="modal-overlay" id="editModal"><div class="modal"><div class="modal-header"><span class="modal-title">Edit Animal</span><button class="modal-close" onclick="closeModal('editModal')">✕</button></div>
<form method="POST"><input type="hidden" name="action" value="edit"><input type="hidden" name="id" id="e_id">
<div class="form-grid"><div class="form-group"><label class="form-label">Name *</label><input type="text" name="name" id="e_name" class="form-control" required></div><div class="form-group"><label class="form-label">Species</label><input type="text" name="species" id="e_spec" class="form-control"></div></div>
<div class="form-grid"><div class="form-group"><label class="form-label">Category</label><select name="category_id" id="e_cat" class="form-control"><?php $categories->data_seek(0);while($c=$categories->fetch_assoc()): ?><option value="<?=$c['id']?>"><?=htmlspecialchars($c['name'])?></option><?php endwhile; ?></select></div>
<div class="form-group"><label class="form-label">Supplier</label><select name="supplier_id" id="e_sup" class="form-control"><?php $suppliers->data_seek(0);while($s=$suppliers->fetch_assoc()): ?><option value="<?=$s['id']?>"><?=htmlspecialchars($s['name'])?></option><?php endwhile; ?></select></div></div>
<div class="form-grid-3"><div class="form-group"><label class="form-label">Buy Price</label><input type="number" name="buying_price" id="e_buy" class="form-control" step="0.01"></div><div class="form-group"><label class="form-label">Sell Price</label><input type="number" name="selling_price" id="e_sell" class="form-control" step="0.01"></div><div class="form-group"><label class="form-label">Care Level</label><select name="care_level" id="e_care" class="form-control"><option value="easy">Easy</option><option value="moderate">Moderate</option><option value="expert">Expert</option></select></div></div>
<div class="form-grid"><div class="form-group"><label class="form-label">Stock</label><input type="number" name="stock_quantity" id="e_qty" class="form-control"></div><div class="form-group"><label class="form-label">Alert At</label><input type="number" name="low_stock_alert" id="e_alert" class="form-control"></div></div>
<div class="form-group"><label class="form-label">Description</label><textarea name="description" id="e_desc" class="form-control" rows="2"></textarea></div>
<button type="submit" class="btn btn-amber" style="width:100%;justify-content:center">Update Animal</button></form></div></div>
<script>
function openModal(id){document.getElementById(id).classList.add('open');}function closeModal(id){document.getElementById(id).classList.remove('open');}
function editAnimal(d){document.getElementById('e_id').value=d.id;document.getElementById('e_name').value=d.name;document.getElementById('e_spec').value=d.species||'';document.getElementById('e_cat').value=d.category_id||0;document.getElementById('e_sup').value=d.supplier_id||0;document.getElementById('e_buy').value=d.buying_price;document.getElementById('e_sell').value=d.selling_price;document.getElementById('e_qty').value=d.stock_quantity;document.getElementById('e_alert').value=d.low_stock_alert;document.getElementById('e_care').value=d.care_level;document.getElementById('e_desc').value=d.description||'';openModal('editModal');}
function toggleSidebar(){document.getElementById('sidebar').classList.toggle('open');}
</script></div></body></html>
