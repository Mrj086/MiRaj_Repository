<?php
require_once '../includes/config.php';
require_once '../includes/layout.php';
requireLogin();

$msg = ''; $msgType = 'success';

$deptMap = [
    'Animal Food'  => ['Cat Food','Dog Food','Fish Food','Bird Food','Small Animal Food','Agro/Farm Animal Food'],
    'Toys'         => ['Cat Toys','Dog Toys','Bird Toys','Rabbit Toys','Small Animal Toys'],
    'Accessories'  => ['Cat Accessories','Dog Accessories','Aquarium Accessories','Bird Accessories','Small Animal Accessories'],
    'Medicine'     => ['Cat Medicine','Dog Medicine','Fish Medicine','General Pet Medicine'],
    'Grooming'     => ['Cat Grooming','Dog Grooming','General Grooming'],
    'Aquarium'     => ['Filters','Heaters','Lighting','Gravel & Decor','Water Treatment'],
    'Other'        => ['Other'],
];
$allDepts = array_keys($deptMap);

function handleImageUpload($fieldName, $oldImage = '') {
    if (!isset($_FILES[$fieldName]) || $_FILES[$fieldName]['error'] === UPLOAD_ERR_NO_FILE) return $oldImage;
    $file = $_FILES[$fieldName];
    $allowed = ['image/jpeg','image/jpg','image/png','image/gif','image/webp'];
    if ($file['error'] !== UPLOAD_ERR_OK)   return ['error'=>'Upload failed.'];
    if (!in_array($file['type'], $allowed)) return ['error'=>'Only JPG, PNG, WEBP allowed.'];
    if ($file['size'] > 2*1024*1024)        return ['error'=>'Max 2MB per image.'];
    $ext  = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    $fn   = 'prod_'.time().'_'.rand(1000,9999).'.'.$ext;
    $dest = '../assets/uploads/products/'.$fn;
    if (move_uploaded_file($file['tmp_name'], $dest)) {
        if ($oldImage && file_exists('../assets/uploads/products/'.$oldImage)) unlink('../assets/uploads/products/'.$oldImage);
        return $fn;
    }
    return ['error'=>'Could not save. Check folder permissions.'];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    if ($action === 'add' || $action === 'edit') {
        $id   = (int)($_POST['id'] ?? 0);
        $name = clean($_POST['name']);
        $dept = clean($_POST['department']);
        $sc   = clean($_POST['sub_category']);
        $desc = clean($_POST['description']);
        $sup  = (int)$_POST['supplier_id'];
        $buy  = (float)$_POST['buying_price'];
        $sell = (float)$_POST['selling_price'];
        $qty  = (int)$_POST['stock_quantity'];
        $alrt = (int)$_POST['low_stock_alert'];

        $oldImg = '';
        if ($action === 'edit' && $id) {
            $r = $conn->query("SELECT image FROM products WHERE id=$id")->fetch_assoc();
            $oldImg = $r['image'] ?? '';
        }
        $imgResult = handleImageUpload('product_image', $oldImg);
        if (is_array($imgResult) && isset($imgResult['error'])) {
            $msg = $imgResult['error']; $msgType = 'danger';
        } else {
            $image = clean($imgResult ?? '');
            if ($action === 'add') {
                $conn->query("INSERT INTO products (supplier_id,name,department,sub_category,description,buying_price,selling_price,stock_quantity,low_stock_alert,image) VALUES ($sup,'$name','$dept','$sc','$desc',$buy,$sell,$qty,$alrt,'$image')");
                $msg = "Product '$name' added!";
            } else {
                $conn->query("UPDATE products SET supplier_id=$sup,name='$name',department='$dept',sub_category='$sc',description='$desc',buying_price=$buy,selling_price=$sell,stock_quantity=$qty,low_stock_alert=$alrt,image='$image' WHERE id=$id");
                $msg = "Product updated!";
            }
        }
    }
    if ($action === 'delete' && isAdmin()) {
        $id = (int)$_POST['id'];
        $r  = $conn->query("SELECT image FROM products WHERE id=$id")->fetch_assoc();
        if (!empty($r['image']) && file_exists('../assets/uploads/products/'.$r['image'])) unlink('../assets/uploads/products/'.$r['image']);
        $conn->query("DELETE FROM products WHERE id=$id");
        $msg = "Deleted."; $msgType = 'warning';
    }
}

$search  = clean($_GET['search']  ?? '');
$fDept   = clean($_GET['dept']    ?? '');
$fSub    = clean($_GET['subcat']  ?? '');
$view    = $_GET['view'] ?? 'table';

$where = 'WHERE 1=1';
if ($search) $where .= " AND p.name LIKE '%$search%'";
if ($fDept)  $where .= " AND p.department='$fDept'";
if ($fSub)   $where .= " AND p.sub_category='$fSub'";

$products  = $conn->query("SELECT p.*,s.name sup_name FROM products p LEFT JOIN suppliers s ON p.supplier_id=s.id $where ORDER BY p.department,p.sub_category,p.name");
$suppliers = $conn->query("SELECT * FROM suppliers ORDER BY name");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Products — Uttara Pet Shop</title>
<link rel="stylesheet" href="../assets/css/style.css">
<style>
.prod-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(190px,1fr));gap:16px}
.prod-card{background:var(--bg-card);border:1px solid var(--border);border-radius:var(--radius);overflow:hidden;box-shadow:var(--shadow);transition:transform .2s,box-shadow .2s}
.prod-card:hover{transform:translateY(-3px);box-shadow:var(--shadow-lg)}
.prod-card-img{width:100%;height:148px;object-fit:cover;display:block;background:var(--cream-dark)}
.prod-card-ph{width:100%;height:148px;display:flex;align-items:center;justify-content:center;font-size:46px;background:var(--cream-dark)}
.prod-card-body{padding:12px}
.prod-card-name{font-weight:600;font-size:13px;color:var(--brown-deep);margin-bottom:4px;line-height:1.3}
.prod-card-meta{font-size:11px;color:var(--text-muted);margin-bottom:6px}
.prod-card-price{font-family:'DM Mono';font-size:14px;color:var(--amber);font-weight:500}
.prod-card-actions{display:flex;gap:6px;padding:8px 12px;border-top:1px solid var(--border)}
.prod-thumb{width:52px;height:52px;border-radius:8px;object-fit:cover;border:1px solid var(--border)}
.prod-thumb-ph{width:52px;height:52px;border-radius:8px;background:var(--cream-dark);border:1px solid var(--border);display:flex;align-items:center;justify-content:center;font-size:20px}
.upload-box{border:2px dashed var(--border-dark);border-radius:var(--radius-sm);padding:16px;text-align:center;cursor:pointer;background:var(--cream);position:relative;transition:all .2s}
.upload-box:hover{border-color:var(--forest-mid);background:var(--bg-hover)}
.upload-box input[type=file]{position:absolute;inset:0;opacity:0;cursor:pointer;width:100%;height:100%}
.prev-wrap{display:none;margin-top:8px;text-align:center}
.prev-wrap img{width:80px;height:80px;object-fit:cover;border-radius:8px;border:2px solid var(--forest-mid)}
.view-btn{padding:7px 13px;border-radius:6px;border:1.5px solid var(--border-dark);background:transparent;cursor:pointer;font-size:15px;transition:all .15s;color:var(--text-mid);text-decoration:none;display:inline-flex;align-items:center}
.view-btn.active{background:var(--forest);color:#fff;border-color:var(--forest)}
.dept-badge{display:inline-block;padding:2px 9px;border-radius:20px;font-size:11px;font-weight:600}
.db-AF{background:rgba(212,130,10,0.12);color:var(--amber)}
.db-T{background:rgba(201,74,42,0.1);color:var(--coral)}
.db-Ac{background:rgba(45,80,22,0.1);color:var(--forest-mid)}
.db-M{background:rgba(30,100,180,0.1);color:#1e64b4}
.db-G{background:rgba(122,79,45,0.12);color:var(--brown-light)}
.db-Aq{background:rgba(0,150,180,0.1);color:#0096b4}
.db-O{background:rgba(196,168,130,0.2);color:var(--brown-light)}
</style>
</head>
<body>
<?php renderSidebar('products'); ?>
<div class="main">
<?php pageHeader('📦 Products','All products organized by department & category'); ?>
<?php if($msg): ?><div class="alert alert-<?=$msgType?>"><?=$msg?></div><?php endif; ?>

<!-- FILTER BAR -->
<div class="card" style="margin-bottom:16px;padding:16px">
<form method="GET" style="display:flex;gap:10px;flex-wrap:wrap;align-items:flex-end">
    <input type="hidden" name="view" value="<?=htmlspecialchars($view)?>">
    <div class="form-group" style="margin:0;flex:1;min-width:150px">
        <label class="form-label">Search</label>
        <input type="text" name="search" class="form-control" placeholder="Product name..." value="<?=htmlspecialchars($search)?>">
    </div>
    <div class="form-group" style="margin:0;flex:0 0 170px">
        <label class="form-label">Department</label>
        <select name="dept" class="form-control" onchange="this.form.submit()">
            <option value="">All Departments</option>
            <?php foreach($allDepts as $d): ?>
            <option value="<?=$d?>" <?=$fDept===$d?'selected':''?>><?=$d?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <?php if($fDept && !empty($deptMap[$fDept])): ?>
    <div class="form-group" style="margin:0;flex:0 0 180px">
        <label class="form-label">Category</label>
        <select name="subcat" class="form-control">
            <option value="">All Categories</option>
            <?php foreach($deptMap[$fDept] as $sc): ?>
            <option value="<?=$sc?>" <?=$fSub===$sc?'selected':''?>><?=$sc?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <?php endif; ?>
    <button type="submit" class="btn btn-primary">Filter</button>
    <a href="products.php" class="btn btn-outline">Clear</a>
</form>
</div>

<!-- ACTIONS BAR -->
<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px;flex-wrap:wrap;gap:10px">
    <h2 style="font-family:'Playfair Display',serif;font-size:18px;color:var(--brown-deep)">
        <?=htmlspecialchars($fDept?:' All Products')?>
        <?php if($fSub): ?><span style="font-size:13px;font-weight:400;color:var(--text-muted)"> → <?=htmlspecialchars($fSub)?></span><?php endif; ?>
        <span style="font-size:13px;font-weight:400;color:var(--text-muted);margin-left:8px">(<?=$products->num_rows?> items)</span>
    </h2>
    <div style="display:flex;gap:8px;align-items:center">
        <a href="?<?=http_build_query(array_merge($_GET,['view'=>'table']))?>" class="view-btn <?=$view==='table'?'active':''?>" title="Table">☰</a>
        <a href="?<?=http_build_query(array_merge($_GET,['view'=>'grid']))?>"  class="view-btn <?=$view==='grid' ?'active':''?>" title="Gallery">⊞</a>
        <button class="btn btn-primary" onclick="openModal('addModal')">+ Add Product</button>
    </div>
</div>

<?php
// dept to badge class map
function deptClass($dept) {
    $map=['Animal Food'=>'AF','Toys'=>'T','Accessories'=>'Ac','Medicine'=>'M','Grooming'=>'G','Aquarium'=>'Aq','Other'=>'O'];
    return 'db-'.($map[$dept]??'O');
}
?>

<!-- TABLE VIEW -->
<?php if($view==='table'): ?>
<div class="card"><div class="table-wrap"><table>
<thead><tr><th>Photo</th><th>#</th><th>Name</th><th>Department</th><th>Category</th><th>Supplier</th><th>Buy</th><th>Sell</th><th>Stock</th><th>Actions</th></tr></thead>
<tbody>
<?php $i=1;while($r=$products->fetch_assoc()): ?>
<tr class="<?=$r['stock_quantity']<=$r['low_stock_alert']?'low-stock-row':''?>">
<td><?php if(!empty($r['image'])&&file_exists('../assets/uploads/products/'.$r['image'])): ?><img src="../assets/uploads/products/<?=htmlspecialchars($r['image'])?>" class="prod-thumb"><?php else: ?><div class="prod-thumb-ph">📦</div><?php endif; ?></td>
<td style="color:var(--text-muted)"><?=$i++?></td>
<td><b style="color:var(--brown-deep)"><?=htmlspecialchars($r['name'])?></b><?php if(!empty($r['description'])): ?><div style="font-size:11px;color:var(--text-muted);margin-top:1px"><?=htmlspecialchars(substr($r['description'],0,38))?>...</div><?php endif; ?></td>
<td><span class="dept-badge <?=deptClass($r['department']??'')?>"><?=htmlspecialchars($r['department']??'—')?></span></td>
<td style="font-size:12px;color:var(--text-mid)"><?=htmlspecialchars($r['sub_category']??'—')?></td>
<td style="font-size:12px;color:var(--text-muted)"><?=htmlspecialchars($r['sup_name']??'—')?></td>
<td><?=money($r['buying_price'])?></td>
<td style="color:var(--amber);font-weight:600"><?=money($r['selling_price'])?></td>
<td><?=$r['stock_quantity']<=$r['low_stock_alert']?'<span class="badge badge-coral">'.$r['stock_quantity'].' ⚠</span>':'<span class="badge badge-green">'.$r['stock_quantity'].'</span>'?></td>
<td>
<button class="btn btn-outline btn-sm" onclick='editProduct(<?=json_encode($r)?>)'>Edit</button>
<?php if(isAdmin()): ?><form method="POST" enctype="multipart/form-data" style="display:inline" onsubmit="return confirm('Delete?')"><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?=$r['id']?>"><button type="submit" class="btn btn-danger btn-sm">Del</button></form><?php endif; ?>
</td>
</tr>
<?php endwhile; ?>
<?php if($products->num_rows===0): ?><tr><td colspan="10" style="text-align:center;padding:32px;color:var(--text-muted)">No products found. <button class="btn btn-primary btn-sm" onclick="openModal('addModal')">Add first product</button></td></tr><?php endif; ?>
</tbody></table></div></div>

<!-- GRID VIEW -->
<?php else: ?>
<?php $products->data_seek(0); ?>
<?php if($products->num_rows===0): ?>
<div class="card" style="text-align:center;padding:40px;color:var(--text-muted)">No products found. <button class="btn btn-primary btn-sm" onclick="openModal('addModal')">Add first product</button></div>
<?php else: ?>
<div class="prod-grid">
<?php while($r=$products->fetch_assoc()): ?>
<div class="prod-card">
<?php if(!empty($r['image'])&&file_exists('../assets/uploads/products/'.$r['image'])): ?>
<img src="../assets/uploads/products/<?=htmlspecialchars($r['image'])?>" class="prod-card-img" alt="<?=htmlspecialchars($r['name'])?>">
<?php else: ?><div class="prod-card-ph">📦</div><?php endif; ?>
<div class="prod-card-body">
    <div class="prod-card-name"><?=htmlspecialchars($r['name'])?></div>
    <div class="prod-card-meta">
        <span class="dept-badge <?=deptClass($r['department']??'')?>" style="font-size:10px"><?=htmlspecialchars($r['department']??'—')?></span>
        <?php if(!empty($r['sub_category'])): ?><br><span style="font-size:11px;color:var(--text-muted)"><?=htmlspecialchars($r['sub_category'])?></span><?php endif; ?>
    </div>
    <div class="prod-card-price"><?=money($r['selling_price'])?></div>
    <div style="margin-top:4px"><?=$r['stock_quantity']<=$r['low_stock_alert']?'<span class="badge badge-coral" style="font-size:10px">Stock: '.$r['stock_quantity'].' ⚠</span>':'<span class="badge badge-green" style="font-size:10px">Stock: '.$r['stock_quantity'].'</span>'?></div>
</div>
<div class="prod-card-actions">
<button class="btn btn-outline btn-sm" style="flex:1;justify-content:center" onclick='editProduct(<?=json_encode($r)?>)'>Edit</button>
<?php if(isAdmin()): ?><form method="POST" enctype="multipart/form-data" onsubmit="return confirm('Delete?')"><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?=$r['id']?>"><button type="submit" class="btn btn-danger btn-sm">Del</button></form><?php endif; ?>
</div>
</div>
<?php endwhile; ?>
</div>
<?php endif; endif; ?>

<!-- ADD MODAL -->
<div class="modal-overlay" id="addModal"><div class="modal">
<div class="modal-header"><span class="modal-title">📦 Add New Product</span><button class="modal-close" onclick="closeModal('addModal')">✕</button></div>
<form method="POST" enctype="multipart/form-data">
<input type="hidden" name="action" value="add">
<div class="form-group"><label class="form-label">Product Name *</label><input type="text" name="name" class="form-control" required placeholder="e.g. Whiskas Dry Cat Food 500g"></div>
<div class="form-grid">
<div class="form-group"><label class="form-label">Department *</label>
<select name="department" id="add_dept" class="form-control" onchange="loadSubCats(this.value,'add_sc')" required>
<option value="">-- Select Department --</option>
<?php foreach($allDepts as $d): ?><option value="<?=$d?>"><?=$d?></option><?php endforeach; ?>
</select></div>
<div class="form-group"><label class="form-label">Category *</label>
<select name="sub_category" id="add_sc" class="form-control" required>
<option value="">-- Pick Department First --</option>
</select></div>
</div>
<div class="form-group"><label class="form-label">Product Photo</label>
<div class="upload-box"><input type="file" name="product_image" accept="image/*" onchange="prevImg(this,'ap')">
<div style="pointer-events:none"><div style="font-size:28px;margin-bottom:4px">🖼️</div><div style="font-size:12px;color:var(--text-light);font-weight:500">Click to upload photo</div><div style="font-size:11px;color:var(--text-muted);margin-top:2px">JPG, PNG, WEBP · Max 2MB</div></div></div>
<div class="prev-wrap" id="ap"><img src="" alt="Preview"><div style="font-size:11px;color:var(--forest);margin-top:4px">✅ Ready to upload</div></div></div>
<div class="form-group"><label class="form-label">Supplier</label>
<select name="supplier_id" class="form-control"><option value="0">-- Select --</option>
<?php $suppliers->data_seek(0);while($s=$suppliers->fetch_assoc()): ?><option value="<?=$s['id']?>"><?=htmlspecialchars($s['name'])?></option><?php endwhile; ?>
</select></div>
<div class="form-grid">
<div class="form-group"><label class="form-label">Buying Price (৳) *</label><input type="number" name="buying_price" class="form-control" step="0.01" required placeholder="0.00"></div>
<div class="form-group"><label class="form-label">Selling Price (৳) *</label><input type="number" name="selling_price" class="form-control" step="0.01" required placeholder="0.00"></div>
</div>
<div class="form-grid">
<div class="form-group"><label class="form-label">Stock Qty</label><input type="number" name="stock_quantity" class="form-control" value="0"></div>
<div class="form-group"><label class="form-label">Low Stock Alert</label><input type="number" name="low_stock_alert" class="form-control" value="5"></div>
</div>
<div class="form-group"><label class="form-label">Description</label><textarea name="description" class="form-control" rows="2" placeholder="Brief description..."></textarea></div>
<button type="submit" class="btn btn-primary" style="width:100%;justify-content:center">Add Product</button>
</form></div></div>

<!-- EDIT MODAL -->
<div class="modal-overlay" id="editModal"><div class="modal">
<div class="modal-header"><span class="modal-title">✏️ Edit Product</span><button class="modal-close" onclick="closeModal('editModal')">✕</button></div>
<form method="POST" enctype="multipart/form-data">
<input type="hidden" name="action" value="edit"><input type="hidden" name="id" id="e_id">
<div class="form-group"><label class="form-label">Product Name *</label><input type="text" name="name" id="e_name" class="form-control" required></div>
<div class="form-grid">
<div class="form-group"><label class="form-label">Department *</label>
<select name="department" id="e_dept" class="form-control" onchange="loadSubCats(this.value,'e_sc')" required>
<option value="">-- Select --</option>
<?php foreach($allDepts as $d): ?><option value="<?=$d?>"><?=$d?></option><?php endforeach; ?>
</select></div>
<div class="form-group"><label class="form-label">Category *</label>
<select name="sub_category" id="e_sc" class="form-control" required><option value="">-- Pick Department First --</option></select>
</div></div>
<div class="form-group"><label class="form-label">Product Photo</label>
<div id="e_cw" style="display:none;flex-direction:row;align-items:center;gap:10px;padding:10px;background:var(--cream);border-radius:8px;border:1px solid var(--border);margin-bottom:10px">
<img id="e_ci" src="" style="width:60px;height:60px;object-fit:cover;border-radius:8px" alt="">
<div><div style="font-size:13px;font-weight:500;color:var(--brown-deep)">Current photo</div><div style="font-size:11px;color:var(--text-muted)">Upload below to replace</div></div></div>
<div class="upload-box"><input type="file" name="product_image" accept="image/*" onchange="prevImg(this,'ep')">
<div style="pointer-events:none"><div style="font-size:24px;margin-bottom:3px">📷</div><div style="font-size:12px;color:var(--text-light)">Upload new photo</div><div style="font-size:11px;color:var(--text-muted);margin-top:2px">Leave empty to keep current</div></div></div>
<div class="prev-wrap" id="ep"><img src="" alt="New preview"><div style="font-size:11px;color:var(--forest);margin-top:4px">✅ New image selected</div></div></div>
<div class="form-group"><label class="form-label">Supplier</label>
<select name="supplier_id" id="e_sup" class="form-control">
<option value="0">-- Select --</option>
<?php $suppliers->data_seek(0);while($s=$suppliers->fetch_assoc()): ?><option value="<?=$s['id']?>"><?=htmlspecialchars($s['name'])?></option><?php endwhile; ?>
</select></div>
<div class="form-grid">
<div class="form-group"><label class="form-label">Buying Price (৳)</label><input type="number" name="buying_price" id="e_buy" class="form-control" step="0.01"></div>
<div class="form-group"><label class="form-label">Selling Price (৳)</label><input type="number" name="selling_price" id="e_sell" class="form-control" step="0.01"></div>
</div>
<div class="form-grid">
<div class="form-group"><label class="form-label">Stock Qty</label><input type="number" name="stock_quantity" id="e_qty" class="form-control"></div>
<div class="form-group"><label class="form-label">Low Stock Alert</label><input type="number" name="low_stock_alert" id="e_alert" class="form-control"></div>
</div>
<div class="form-group"><label class="form-label">Description</label><textarea name="description" id="e_desc" class="form-control" rows="2"></textarea></div>
<button type="submit" class="btn btn-amber" style="width:100%;justify-content:center">Update Product</button>
</form></div></div>

<script>
const deptMap = <?= json_encode($deptMap) ?>;

function loadSubCats(dept, targetId) {
    const sel = document.getElementById(targetId);
    sel.innerHTML = '<option value="">-- Select Category --</option>';
    if (dept && deptMap[dept]) {
        deptMap[dept].forEach(sc => {
            const opt = document.createElement('option');
            opt.value = sc; opt.textContent = sc;
            sel.appendChild(opt);
        });
    }
}

function openModal(id)  { document.getElementById(id).classList.add('open'); }
function closeModal(id) { document.getElementById(id).classList.remove('open'); }

function prevImg(input, id) {
    if (input.files && input.files[0]) {
        const r = new FileReader();
        r.onload = e => {
            const w = document.getElementById(id);
            w.querySelector('img').src = e.target.result;
            w.style.display = 'block';
        };
        r.readAsDataURL(input.files[0]);
    }
}

function editProduct(d) {
    document.getElementById('e_id').value    = d.id;
    document.getElementById('e_name').value  = d.name;
    document.getElementById('e_buy').value   = d.buying_price;
    document.getElementById('e_sell').value  = d.selling_price;
    document.getElementById('e_qty').value   = d.stock_quantity;
    document.getElementById('e_alert').value = d.low_stock_alert;
    document.getElementById('e_desc').value  = d.description || '';
    document.getElementById('e_sup').value   = d.supplier_id || 0;

    // Set department then sub_category
    document.getElementById('e_dept').value = d.department || '';
    loadSubCats(d.department || '', 'e_sc');
    setTimeout(() => {
        document.getElementById('e_sc').value = d.sub_category || '';
    }, 20);

    // Current image
    const cw = document.getElementById('e_cw');
    const ci = document.getElementById('e_ci');
    if (d.image) {
        ci.src = '../assets/uploads/products/' + d.image;
        cw.style.display = 'flex';
    } else {
        cw.style.display = 'none';
    }
    document.getElementById('ep').style.display = 'none';
    openModal('editModal');
}

function toggleSidebar() { document.getElementById('sidebar').classList.toggle('open'); }
</script>
</div>
</body>
</html>
