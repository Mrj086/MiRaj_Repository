<?php
require_once '../includes/config.php';
requireLogin();
$po_id=(int)($_GET['po_id']??0);
$items=$conn->query("SELECT * FROM purchase_order_items WHERE po_id=$po_id");
$po   =$conn->query("SELECT * FROM purchase_orders WHERE id=$po_id")->fetch_assoc();
if(!$po){echo"<p>Not found</p>";exit();}
echo '<table style="width:100%;border-collapse:collapse">';
echo '<thead><tr><th style="text-align:left;padding:8px;border-bottom:2px solid var(--border);font-size:11px;text-transform:uppercase;color:var(--text-light)">Item</th><th style="text-align:left;padding:8px;border-bottom:2px solid var(--border);font-size:11px;text-transform:uppercase;color:var(--text-light)">Type</th><th style="text-align:right;padding:8px;border-bottom:2px solid var(--border);font-size:11px;text-transform:uppercase;color:var(--text-light)">Ordered</th><th style="text-align:right;padding:8px;border-bottom:2px solid var(--border);font-size:11px;text-transform:uppercase;color:var(--text-light)">Received</th><th style="text-align:right;padding:8px;border-bottom:2px solid var(--border);font-size:11px;text-transform:uppercase;color:var(--text-light)">Unit Price</th><th style="text-align:right;padding:8px;border-bottom:2px solid var(--border);font-size:11px;text-transform:uppercase;color:var(--text-light)">Total</th></tr></thead><tbody>';
$grand=0;
while($r=$items->fetch_assoc()):
    $line=$r['quantity_ordered']*$r['unit_price'];$grand+=$line;
    echo '<tr>
    <td style="padding:10px 8px;border-bottom:1px solid var(--cream-dark);font-size:13px;color:var(--text-dark)"><b>'.htmlspecialchars($r['item_name']).'</b></td>
    <td style="padding:10px 8px;border-bottom:1px solid var(--cream-dark)"><span class="badge badge-sand">'.ucfirst($r['item_type']).'</span></td>
    <td style="padding:10px 8px;border-bottom:1px solid var(--cream-dark);text-align:right">'.$r['quantity_ordered'].'</td>
    <td style="padding:10px 8px;border-bottom:1px solid var(--cream-dark);text-align:right;color:'.($r['quantity_received']>0?'var(--forest)':'var(--text-muted)').'">'.$r['quantity_received'].'</td>
    <td style="padding:10px 8px;border-bottom:1px solid var(--cream-dark);text-align:right">'.money($r['unit_price']).'</td>
    <td style="padding:10px 8px;border-bottom:1px solid var(--cream-dark);text-align:right;font-weight:600;color:var(--amber)">'.money($line).'</td>
    </tr>';
endwhile;
echo '</tbody></table>';
echo '<div style="display:flex;justify-content:space-between;padding:12px 8px;border-top:2px solid var(--border);font-weight:700;font-size:14px"><span>Total</span><span style="color:var(--amber);font-family:DM Mono">'.money($grand).'</span></div>';
echo '<div style="padding:10px 8px;font-size:12px;color:var(--text-muted)">Status: <b style="color:var(--brown-deep)">'.ucfirst(str_replace('_',' ',$po['status'])).'</b> &nbsp;|&nbsp; Payment: '.paymentLabel($po['payment_method']).'</div>';
?>
