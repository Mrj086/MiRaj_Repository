-- =============================================
--  Uttara Pet Shop v3 — Full Featured Database
-- =============================================
DROP DATABASE IF EXISTS uttara_petshop;
CREATE DATABASE uttara_petshop;
USE uttara_petshop;

-- USERS (multiple cashiers supported)
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('admin','cashier') DEFAULT 'cashier',
    is_active TINYINT DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- CATEGORIES
CREATE TABLE categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    type ENUM('animal','product') NOT NULL,
    description TEXT
);

-- SUPPLIERS
CREATE TABLE suppliers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    contact_person VARCHAR(100),
    phone VARCHAR(20),
    email VARCHAR(100),
    address TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ANIMALS
CREATE TABLE animals (
    id INT AUTO_INCREMENT PRIMARY KEY,
    category_id INT, supplier_id INT,
    name VARCHAR(150) NOT NULL, species VARCHAR(150),
    description TEXT,
    buying_price DECIMAL(10,2) NOT NULL DEFAULT 0,
    selling_price DECIMAL(10,2) NOT NULL DEFAULT 0,
    stock_quantity INT DEFAULT 0,
    low_stock_alert INT DEFAULT 2,
    care_level ENUM('easy','moderate','expert') DEFAULT 'easy',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL,
    FOREIGN KEY (supplier_id) REFERENCES suppliers(id) ON DELETE SET NULL
);

-- PRODUCTS
CREATE TABLE products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    category_id INT, supplier_id INT,
    name VARCHAR(150) NOT NULL, description TEXT,
    buying_price DECIMAL(10,2) NOT NULL DEFAULT 0,
    selling_price DECIMAL(10,2) NOT NULL DEFAULT 0,
    stock_quantity INT DEFAULT 0,
    low_stock_alert INT DEFAULT 5,
    image VARCHAR(255) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL,
    FOREIGN KEY (supplier_id) REFERENCES suppliers(id) ON DELETE SET NULL
);

-- AQUARIUMS
CREATE TABLE aquariums (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) NOT NULL, size_liters DECIMAL(8,2),
    description TEXT,
    price DECIMAL(10,2) NOT NULL DEFAULT 0,
    stock_quantity INT DEFAULT 0,
    material ENUM('glass','acrylic','other') DEFAULT 'glass',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- CUSTOMERS
CREATE TABLE customers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    phone VARCHAR(20), email VARCHAR(100), address TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- SALES
CREATE TABLE sales (
    id INT AUTO_INCREMENT PRIMARY KEY,
    invoice_no VARCHAR(30) UNIQUE NOT NULL,
    customer_id INT, user_id INT,
    subtotal DECIMAL(10,2) NOT NULL DEFAULT 0,
    discount DECIMAL(10,2) DEFAULT 0,
    total DECIMAL(10,2) NOT NULL DEFAULT 0,
    payment_method ENUM('cash','card','bkash_personal','bkash_merchant','nagad','rocket') DEFAULT 'cash',
    payment_ref VARCHAR(100) DEFAULT NULL,
    sale_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    notes TEXT,
    FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE SET NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

-- SALE ITEMS
CREATE TABLE sale_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    sale_id INT NOT NULL,
    item_type ENUM('product','animal','aquarium') NOT NULL,
    item_id INT NOT NULL,
    item_name VARCHAR(150),
    quantity INT NOT NULL,
    unit_price DECIMAL(10,2) NOT NULL,
    total_price DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (sale_id) REFERENCES sales(id) ON DELETE CASCADE
);

-- PURCHASE ORDERS (supplier billing + stock tracking)
CREATE TABLE purchase_orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    po_number VARCHAR(30) UNIQUE NOT NULL,
    supplier_id INT,
    user_id INT,
    status ENUM('ordered','partially_received','received','cancelled') DEFAULT 'ordered',
    total_amount DECIMAL(10,2) DEFAULT 0,
    amount_paid DECIMAL(10,2) DEFAULT 0,
    payment_method ENUM('cash','bank_transfer','bkash_personal','bkash_merchant','nagad','rocket','credit') DEFAULT 'cash',
    payment_ref VARCHAR(100),
    order_date DATE NOT NULL,
    expected_arrival DATE,
    arrival_date DATE,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (supplier_id) REFERENCES suppliers(id) ON DELETE SET NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

-- PURCHASE ORDER ITEMS
CREATE TABLE purchase_order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    po_id INT NOT NULL,
    item_type ENUM('product','animal','aquarium') NOT NULL,
    item_id INT NOT NULL,
    item_name VARCHAR(150),
    quantity_ordered INT NOT NULL,
    quantity_received INT DEFAULT 0,
    unit_price DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (po_id) REFERENCES purchase_orders(id) ON DELETE CASCADE
);

-- NOTIFICATIONS
CREATE TABLE notifications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    type ENUM('low_stock','new_sale','new_purchase','stock_received','payment_due','custom') NOT NULL,
    title VARCHAR(200) NOT NULL,
    message TEXT NOT NULL,
    link VARCHAR(255) DEFAULT NULL,
    is_read TINYINT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- EXPENSES
CREATE TABLE expenses (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(150) NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    category VARCHAR(100),
    expense_date DATE NOT NULL,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- =============================================
-- SAMPLE DATA
-- Admin: admin / admin123
-- Cashier: cashier1 / cash2024
-- =============================================
INSERT INTO users (full_name, username, password, role) VALUES
('Shop Admin',    'admin',    MD5('admin123'), 'admin'),
('Rahim Cashier', 'cashier1', MD5('cash2024'), 'cashier'),
('Karim Cashier', 'cashier2', MD5('cash2024'), 'cashier');

INSERT INTO categories (name, type) VALUES
('Freshwater Fish','animal'),('Marine Fish','animal'),
('Birds','animal'),('Reptiles','animal'),('Mammals','animal'),
('Fish Food','product'),('Aquarium Supplies','product'),
('Bird Supplies','product'),('Pet Accessories','product'),
('Medicine & Health','product');

INSERT INTO suppliers (name, contact_person, phone, email, address) VALUES
('AquaLife Imports',  'Kamal Hossain', '01711000001', 'kamal@aqualife.com',  'Dhaka, BD'),
('PetWorld BD',       'Rina Akter',    '01811000002', 'rina@petworldbd.com', 'Chittagong, BD'),
('Ocean Traders',     'Fahim Islam',   '01911000003', 'fahim@ocean.com',     'Uttara, Dhaka');

INSERT INTO customers (name, phone, email) VALUES
('Walk-in Customer', '0000000000', 'walkin@store.com'),
('Arif Rahman',      '01700000001', 'arif@gmail.com'),
('Sadia Islam',      '01800000002', 'sadia@gmail.com');

INSERT INTO animals (category_id,supplier_id,name,species,buying_price,selling_price,stock_quantity,care_level) VALUES
(1,1,'Guppy (Pair)','Poecilia reticulata',30,80,50,'easy'),
(1,1,'Betta Fish','Betta splendens',80,200,20,'easy'),
(1,1,'Goldfish','Carassius auratus',50,120,30,'easy'),
(2,3,'Clownfish','Amphiprioninae',300,800,10,'moderate'),
(3,2,'Budgerigar','Melopsittacus undulatus',500,1200,8,'easy'),
(4,2,'Red-Eared Slider','Trachemys scripta',400,900,5,'moderate');

INSERT INTO products (category_id,supplier_id,name,buying_price,selling_price,stock_quantity) VALUES
(6,2,'Tetra Fish Flakes 100g',120,250,40),
(6,2,'Hikari Betta Pellets',150,300,25),
(7,1,'Internal Filter 500L/h',600,1200,15),
(7,1,'Aquarium Heater 100W',500,1000,12),
(9,2,'Fish Net Small',50,120,30),
(8,2,'Bird Cage Medium',1200,2500,6);

INSERT INTO aquariums (name,size_liters,price,stock_quantity,material) VALUES
('Nano Tank 20L',20,1500,5,'glass'),
('Standard Tank 60L',60,3000,4,'glass'),
('Reef Ready Tank 120L',120,7500,2,'glass'),
('Acrylic Display 200L',200,15000,1,'acrylic');

INSERT INTO notifications (type,title,message,link) VALUES
('custom','Welcome to Uttara Pet Shop!','System is ready. Start by adding products and making sales.','pages/dashboard.php');
