Store product images here. Do not delete this folder.
