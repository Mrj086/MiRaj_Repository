<?php
// includes/config.php
session_start();
define('DB_HOST','localhost'); define('DB_USER','root');
define('DB_PASS','');         define('DB_NAME','uttara_petshop');
define('SHOP_NAME','Uttara Pet Shop');
define('SHOP_TAGLINE','Pet Shop & Aquarium Gallery');
define('CURRENCY','৳');

$conn = new mysqli(DB_HOST,DB_USER,DB_PASS,DB_NAME);
if ($conn->connect_error) {
    die("<div style='font-family:sans-serif;background:#1a0a00;color:#fff;display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0'><div style='background:#2c1a0e;border:1px solid #d4820a;border-radius:12px;padding:40px;max-width:500px;text-align:center'><h2 style='color:#d4820a'>⚠️ Database Error</h2><p>Cannot connect to <b>uttara_petshop</b></p><p style='color:#aaa;font-size:13px'>".$conn->connect_error."</p><p style='color:#aaa;font-size:12px'>Make sure MySQL is running and you imported database.sql</p></div></div>");
}
$conn->set_charset("utf8");

function isLoggedIn()  { return isset($_SESSION['user_id']); }
function isAdmin()     { return isset($_SESSION['role']) && $_SESSION['role']==='admin'; }
function requireLogin(){ if(!isLoggedIn()){ header("Location: ../index.php"); exit(); } }
function clean($v)     { global $conn; return $conn->real_escape_string(trim(strip_tags($v))); }
function money($n)     { return CURRENCY.number_format($n,2); }

function generateInvoiceNo($conn) {
    $y=$conn->query("SELECT COUNT(*) c FROM sales WHERE YEAR(sale_date)=YEAR(NOW())")->fetch_assoc()['c'];
    return 'INV-'.date('Y').'-'.str_pad($y+1,4,'0',STR_PAD_LEFT);
}
function generatePONumber($conn) {
    $y=$conn->query("SELECT COUNT(*) c FROM purchase_orders WHERE YEAR(order_date)=YEAR(NOW())")->fetch_assoc()['c'];
    return 'PO-'.date('Y').'-'.str_pad($y+1,4,'0',STR_PAD_LEFT);
}

// Create a notification
function createNotification($conn,$type,$title,$message,$link='') {
    $title   = $conn->real_escape_string($title);
    $message = $conn->real_escape_string($message);
    $link    = $conn->real_escape_string($link);
    $conn->query("INSERT INTO notifications (type,title,message,link) VALUES ('$type','$title','$message','$link')");
}

// Check and create low-stock notifications
function checkLowStock($conn) {
    $items = $conn->query("
        (SELECT 'product' t, id, name, stock_quantity, low_stock_alert FROM products WHERE stock_quantity<=low_stock_alert)
        UNION
        (SELECT 'animal' t, id, name, stock_quantity, low_stock_alert FROM animals WHERE stock_quantity<=low_stock_alert)
    ");
    while ($r = $items->fetch_assoc()) {
        // Only create if no unread notification for this item exists today
        $name = $conn->real_escape_string($r['name']);
        $existing = $conn->query("SELECT id FROM notifications WHERE type='low_stock' AND title LIKE '%$name%' AND DATE(created_at)=CURDATE() AND is_read=0")->num_rows;
        if (!$existing) {
            createNotification($conn,'low_stock',
                "⚠️ Low Stock: {$r['name']}",
                "Only {$r['stock_quantity']} left (alert threshold: {$r['low_stock_alert']}). Please restock soon.",
                'pages/'.($r['t']==='product'?'products':'animals').'.php'
            );
        }
    }
}

// Get unread notification count
function getUnreadCount($conn) {
    return (int)$conn->query("SELECT COUNT(*) c FROM notifications WHERE is_read=0")->fetch_assoc()['c'];
}

function getDashboardStats($conn) {
    $s=[];
    $s['today_sales']    =$conn->query("SELECT COALESCE(SUM(total),0) v FROM sales WHERE DATE(sale_date)=CURDATE()")->fetch_assoc()['v'];
    $s['month_sales']    =$conn->query("SELECT COALESCE(SUM(total),0) v FROM sales WHERE MONTH(sale_date)=MONTH(NOW()) AND YEAR(sale_date)=YEAR(NOW())")->fetch_assoc()['v'];
    $s['total_animals']  =$conn->query("SELECT COUNT(*) v FROM animals")->fetch_assoc()['v'];
    $s['total_products'] =$conn->query("SELECT COUNT(*) v FROM products")->fetch_assoc()['v'];
    $s['low_stock']      =$conn->query("SELECT COUNT(*) v FROM products WHERE stock_quantity<=low_stock_alert")->fetch_assoc()['v'];
    $s['low_animals']    =$conn->query("SELECT COUNT(*) v FROM animals WHERE stock_quantity<=low_stock_alert")->fetch_assoc()['v'];
    $s['total_customers']=$conn->query("SELECT COUNT(*) v FROM customers")->fetch_assoc()['v'];
    $s['total_sales']    =$conn->query("SELECT COUNT(*) v FROM sales")->fetch_assoc()['v'];
    $s['unread_notifs']  =getUnreadCount($conn);
    return $s;
}

// Payment method labels
function paymentLabel($method) {
    $labels = [
        'cash'            => '💵 Cash',
        'card'            => '💳 Card',
        'bkash_personal'  => '📱 bKash Personal',
        'bkash_merchant'  => '🏪 bKash Merchant',
        'nagad'           => '📲 Nagad',
        'rocket'          => '🚀 Rocket',
        'bank_transfer'   => '🏦 Bank Transfer',
        'credit'          => '📋 Credit',
    ];
    return $labels[$method] ?? ucfirst($method);
}
?>
