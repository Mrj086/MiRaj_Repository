<?php
// includes/layout.php
function renderSidebar($active='') {
    $role = $_SESSION['role'] ?? 'cashier';
    $name = $_SESSION['full_name'] ?? 'User';
    $menu = [
        ['icon'=>'⊞',  'label'=>'Dashboard',       'page'=>'dashboard',  'file'=>'dashboard.php',  'roles'=>['admin','cashier']],
        ['icon'=>'🐾', 'label'=>'Animals',          'page'=>'animals',    'file'=>'animals.php',    'roles'=>['admin','cashier']],
        ['icon'=>'🐟', 'label'=>'Aquariums',        'page'=>'aquariums',  'file'=>'aquariums.php',  'roles'=>['admin','cashier']],
        ['icon'=>'📦', 'label'=>'Products',         'page'=>'products',   'file'=>'products.php',   'roles'=>['admin','cashier']],
        ['icon'=>'🛒', 'label'=>'New Sale',         'page'=>'new_sale',   'file'=>'new_sale.php',   'roles'=>['admin','cashier']],
        ['icon'=>'🧾', 'label'=>'Sales History',    'page'=>'sales',      'file'=>'sales.php',      'roles'=>['admin','cashier']],
        ['icon'=>'👥', 'label'=>'Customers',        'page'=>'customers',  'file'=>'customers.php',  'roles'=>['admin','cashier']],
        ['icon'=>'🚚', 'label'=>'Suppliers',        'page'=>'suppliers',  'file'=>'suppliers.php',  'roles'=>['admin']],
        ['icon'=>'📋', 'label'=>'Purchase Orders',  'page'=>'purchases',  'file'=>'purchases.php',  'roles'=>['admin']],
        ['icon'=>'📊', 'label'=>'Reports',          'page'=>'reports',    'file'=>'reports.php',    'roles'=>['admin']],
        ['icon'=>'👤', 'label'=>'Staff',            'page'=>'staff',      'file'=>'staff.php',      'roles'=>['admin']],
        ['icon'=>'🔔', 'label'=>'Notifications',    'page'=>'notifications','file'=>'notifications.php','roles'=>['admin']],
    ];
    $initials = strtoupper(substr($name,0,2));
    echo '<aside class="sidebar" id="sidebar">
    <div class="sb-brand">
        <span class="sb-paw">🐾</span>
        <div><div class="sb-name">Uttara Pet Shop</div><div class="sb-sub">Pet Shop & Aquarium Gallery</div></div>
    </div>
    <div class="sb-user">
        <div class="sb-avatar">'.$initials.'</div>
        <div><div class="sb-uname">'.htmlspecialchars($name).'</div><div class="sb-urole">'.ucfirst($role).'</div></div>
    </div>
    <nav class="sb-nav">';
    foreach ($menu as $item) {
        if (!in_array($role,$item['roles'])) continue;
        $cls = $active===$item['page']?' active':'';
        echo "<a href='{$item['file']}' class='sb-item$cls'><span class='sb-icon'>{$item['icon']}</span><span>{$item['label']}</span></a>";
    }
    echo '</nav>
    <div class="sb-foot">
        <a href="change_password.php" class="sb-item"><span class="sb-icon">🔑</span><span>Change Password</span></a>
        <a href="../logout.php" class="sb-item sb-logout"><span class="sb-icon">🚪</span><span>Logout</span></a>
    </div></aside>';
}

function pageHeader($title,$sub='',$showNotifBell=true) {
    global $conn;
    $unread = $showNotifBell ? (int)$conn->query("SELECT COUNT(*) c FROM notifications WHERE is_read=0")->fetch_assoc()['c'] : 0;
    $role   = $_SESSION['role'] ?? '';
    echo '<div class="page-hdr">
        <button class="menu-btn" onclick="toggleSidebar()">☰</button>
        <div style="flex:1">
            <h1 class="page-title">'.$title.'</h1>
            '.($sub?"<p class='page-sub'>$sub</p>":'').'
        </div>';
    if ($showNotifBell && $role==='admin') {
        echo '<a href="notifications.php" class="notif-bell" title="Notifications">
            🔔
            '.($unread>0?'<span class="notif-count">'.$unread.'</span>':'').'
        </a>';
    }
    echo '</div>';
}
?>
