<?php
require_once 'includes/config.php';
if (isLoggedIn()) { header("Location: pages/dashboard.php"); exit(); }
$error='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $username = clean($_POST['username']??'');
    $password = $_POST['password']??'';
    if ($username && $password) {
        $hashed = md5($password);
        $stmt = $conn->prepare("SELECT id,full_name,role FROM users WHERE username=? AND password=? AND is_active=1");
        $stmt->bind_param("ss",$username,$hashed);
        $stmt->execute();
        $user = $stmt->get_result()->fetch_assoc();
        if ($user) {
            $_SESSION['user_id']   = $user['id'];
            $_SESSION['full_name'] = $user['full_name'];
            $_SESSION['role']      = $user['role'];
            // Check low stock on login
            checkLowStock($conn);
            header("Location: pages/dashboard.php"); exit();
        } else { $error="Invalid username or password."; }
    } else { $error="Please enter both fields."; }
}
?>
<!DOCTYPE html><html lang="en"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Login — Uttara Pet Shop</title>
<link rel="stylesheet" href="assets/css/style.css">
</head><body>
<div class="login-page">
<div class="login-card">
    <div class="login-logo">
        <span class="login-paw">🐾</span>
        <div class="login-name">Uttara Pet Shop</div>
        <div class="login-sub">Pet Shop & Aquarium Gallery</div>
    </div>
    <?php if($error): ?><div class="alert alert-danger">⚠️ <?=$error?></div><?php endif; ?>
    <form method="POST">
        <div class="form-group">
            <label class="form-label">Username</label>
            <input type="text" name="username" class="form-control" placeholder="Enter username" value="<?=htmlspecialchars($_POST['username']??'')?>" required autofocus>
        </div>
        <div class="form-group">
            <label class="form-label">Password</label>
            <input type="password" name="password" class="form-control" placeholder="Enter password" required>
        </div>
        <button type="submit" class="btn btn-primary" style="width:100%;justify-content:center;padding:12px;font-size:15px;margin-top:6px">Sign In →</button>
    </form>
</div>
</div>
</body></html>
